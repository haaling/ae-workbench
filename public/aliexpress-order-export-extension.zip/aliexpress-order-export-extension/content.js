const STATUS_WAIT_MS = 4000;
const HISTORY_TIMEOUT_MS = 4 * 60 * 1000;
const JZG_DEBUG_PREFIX = '[ae-jzg-debug]';
const RU_SETTLEMENT_DEBUG_PREFIX = '[ae-ru-settlement-debug]';
const HISTORY_DRAWER_OPEN_SELECTOR = '.ait-drawer.aep-drawer.ait-drawer-open, .aep-drawer.ait-drawer-open, .ait-drawer.ait-drawer-open, .ait-drawer-open';
const HISTORY_MODAL_OPEN_SELECTOR = '.ait-modal-wrap .ait-modal, .ait-modal-root .ait-modal, .ait-modal';
let jzgExportInProgress = false;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'START_ORDER_LIST_EXPORT') {
    void runExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_FUND_DETAILS_EXPORT') {
    void runFundDetailsExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_FUND_REFUND_EXPORT') {
    void runFundRefundExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'CAPTURE_FUND_HISTORY_BASELINE') {
    void captureFundHistoryBaseline()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'DOWNLOAD_FUND_HISTORY_BATCH') {
    void downloadFundHistoryBatch(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_JZG_BILL_EXPORT') {
    if (jzgExportInProgress) {
      logJzgDebug('guard.duplicateStartBlocked', {
        reason: 'jzgExportInProgress'
      });
      sendResponse({ ok: true, skipped: true, reason: 'JZG export already running in this page' });
      return;
    }

    jzgExportInProgress = true;
    void runJzgBillExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }))
      .finally(() => {
        jzgExportInProgress = false;
      });

    return true;
  }

  if (message?.type === 'START_SETTLEMENT_BILL_RU_EXPORT') {
    logRuSettlementDebug('message.START_SETTLEMENT_BILL_RU_EXPORT.received', message.payload || {});
    void runSettlementBillRuExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => {
        logRuSettlementDebug('message.START_SETTLEMENT_BILL_RU_EXPORT.failed', {
          error: error?.message || String(error)
        });
        sendResponse({ ok: false, error: error.message || String(error) });
      });

    return true;
  }

  if (message?.type === 'START_SETTLEMENT_BILL_NON_RU_EXPORT') {
    void runSettlementBillNonRuExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }
});

async function runFundDetailsExport(payload) {
  return runFundExportSubmitOnly(payload);
}

async function runSettlementBillRuExport(payload) {
  logRuSettlementDebug('runSettlementBillRuExport.start', payload || {});
  await waitForSelector('body', 20000);
  await ensureRuSettlementPageReady();
  await sleep(300);

  await setRuSettlementDateRange(payload.startDate, payload.endDate);
  logRuSettlementDebug('runSettlementBillRuExport.dateRangeSet', {
    startDate: payload.startDate,
    endDate: payload.endDate
  });
  await sleep(1000);

  logRuSettlementDebug('runSettlementBillRuExport.clickExportDetail', {});
  await clickButtonByText('导出明细', true, true);
  await sleep(1000);
  await waitForFundExportSubmitAck(10000);

  logRuSettlementDebug('runSettlementBillRuExport.openHistory', {});
  const row = await waitForRuFirstRowDownloadableByPopupPolling(180000);
  logRuSettlementDebug('runSettlementBillRuExport.downloadableRowFound', {
    rowText: textOf(row).slice(0, 200)
  });

  const downloadAction = findRuSettlementDownloadAction(row);
  if (!downloadAction) {
    throw new Error('结算账单导出历史中未找到“下载报表”按钮。');
  }

  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: payload.storeTag || 'store',
      monthTag: payload.monthTag || '',
      periodTag: payload.periodTag || '',
      regionTag: payload.regionTag || '俄罗斯',
      fileType: payload.fileType || '结算账单'
    }
  });

  await triggerRuSettlementDownload(downloadAction);
  logRuSettlementDebug('runSettlementBillRuExport.downloadClicked', {
    periodTag: payload.periodTag || '',
    monthTag: payload.monthTag || ''
  });
  await sleep(300);
  await closeHistoryDrawer();

  return {
    rangeText: payload.rangeText || '',
    label: payload.label || ''
  };
}

async function runSettlementBillNonRuExport(payload) {
  await waitForSelector('.ant-tabs-nav, .ant-tabs-tab, .ant-picker-range, .ant-card-body, .ant-row', 25000);
  await sleep(300);

  const startDate = String(payload.startDate || '').trim();
  const endDate = String(payload.endDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    throw new Error(`非俄罗斯结算账单日期范围非法：${startDate} ~ ${endDate}`);
  }

  const rangeText = `${startDate} ~ ${endDate}`;
  showFundNotice(`非俄罗斯结算账单开始处理：${rangeText}`);
  await switchNonRuSettlementSelfTab();
  await setNonRuSettlementSelfDateRange(startDate, endDate);
  await submitNonRuSettlementSelfRange();
  await confirmNonRuSettlementOverwriteIfPresent();

  const resolveTrigger = () => findNonRuSelfBusinessDownloadTrigger();
  const trigger = resolveTrigger();
  if (!trigger) {
    throw new Error('非俄罗斯自选时间段账单未找到“账务动账”下载入口。');
  }

  const stateText = readNonRuDownloadState(trigger);
  if (stateText.includes('下载') && !/(预约|进度|处理中|下载中|生成中)/.test(stateText)) {
    showFundNotice(`非俄罗斯${rangeText} 已可下载，准备点击下载。`);
    await prepareSettlementRename(payload, payload.periodTag || buildDateRangePeriodTag(startDate, endDate));
    clickNonRuDownloadTrigger(trigger);
    await sleep(200);
    return {
      rangeText,
      label: payload.label || ''
    };
  }

  if (stateText.includes('预约')) {
    showFundNotice(`非俄罗斯${rangeText} 当前为预约下载，先触发预约。`);
    clickNonRuDownloadTrigger(trigger);
    await sleep(800);
  }

  const ready = await waitForNonRuDownloadReady(resolveTrigger, 10 * 60 * 1000);
  if (!ready) {
    throw new Error(`非俄罗斯${rangeText}“账务动账”下载未在超时时间内就绪。`);
  }

  showFundNotice(`非俄罗斯${rangeText} 已变为可下载，准备点击下载。`);
  await prepareSettlementRename(payload, payload.periodTag || buildDateRangePeriodTag(startDate, endDate));
  clickNonRuDownloadTrigger(resolveTrigger());
  await sleep(200);

  return {
    rangeText,
    label: payload.label || ''
  };
}

async function ensureRuSettlementPageReady() {
  const hasReadyMarkers = () => {
    const hasDateRange = getRuSettlementRangeInputs().length >= 2;
    const hasExportButton = Boolean(findButtonByText(document, '导出明细'));
    const hasHistoryButton = Boolean(findButtonByText(document, '查看导出历史'));
    return hasDateRange || (hasExportButton && hasHistoryButton);
  };

  if (hasReadyMarkers()) {
    logRuSettlementDebug('ensureRuSettlementPageReady.ready', { href: location.href });
    return;
  }

  logRuSettlementDebug('ensureRuSettlementPageReady.notReady', { href: location.href });

  const settlementLink = document.querySelector('a[href*="/m_apps/r_seller/settlement_bill"]');
  if (settlementLink) {
    clickOnce(settlementLink);
    logRuSettlementDebug('ensureRuSettlementPageReady.clickedSettlementLink', {});
    await sleep(1200);
  }

  await waitUntil(() => hasReadyMarkers(), 12000, `当前页面不是结算账单页（href=${location.href}）或关键元素未渲染`);
  logRuSettlementDebug('ensureRuSettlementPageReady.afterWait.ready', { href: location.href });
}

async function prepareSettlementRename(payload, periodTag) {
  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: payload.storeTag || 'store',
      monthTag: payload.monthTag || payload.targetMonth || '',
      periodTag: payload.periodTag || periodTag,
      regionTag: payload.regionTag || '非俄罗斯',
      fileType: payload.fileType || '结算账单'
    }
  });
}

async function switchNonRuSettlementSelfTab() {
  const isSelfActive = () => {
    const active = document.querySelector('.ant-tabs-tab-active .ant-tabs-tab-btn, [role="tab"][aria-selected="true"]');
    return normalizeButtonText(textOf(active), true).includes('自选时间段账单');
  };

  if (isSelfActive()) {
    return;
  }

  const tab = Array.from(document.querySelectorAll('.ant-tabs-tab-btn, [role="tab"]'))
    .find((node) => normalizeButtonText(textOf(node), true).includes('自选时间段账单'));
  if (!tab) {
    throw new Error('非俄罗斯结算账单未找到“自选时间段账单”Tab。');
  }

  dispatchClick(tab);
  await waitUntil(isSelfActive, 5000, '非俄罗斯结算账单切换“自选时间段账单”失败。');
  await sleep(300);
}

async function setNonRuSettlementSelfDateRange(startDate, endDate) {
  const inputs = getNonRuSettlementSelfRangeInputs();
  if (inputs.length < 2) {
    throw new Error('非俄罗斯自选时间段账单未找到日期范围输入框。');
  }

  await setNonRuSettlementSelfDateRangeByPicker(startDate, endDate);

  await sleep(120);

  const applied = readNonRuSettlementSelfDateRange();
  if (applied.startDate === startDate && applied.endDate === endDate) {
    return;
  }

  await waitUntil(() => {
    const values = readNonRuSettlementSelfDateRange();
    return values.startDate === startDate && values.endDate === endDate;
  }, 4000, `非俄罗斯自选时间段日期范围未生效：${startDate} ~ ${endDate}`);
}

async function setNonRuSettlementSelfDateRangeByPicker(startDate, endDate) {
  const inputs = getNonRuSettlementSelfRangeInputs();
  const picker = inputs[0]?.closest('.ant-picker-range') || inputs[0]?.closest('.ant-picker');
  if (!picker) {
    throw new Error('非俄罗斯自选时间段日期选择器容器不存在。');
  }

  await openNonRuSettlementSelfDatePicker(picker, inputs[0]);

  await ensureAntPickerDateVisible(startDate);
  if (!clickAntDateCellInOpenDropdown(startDate)) {
    throw new Error(`非俄罗斯自选时间段开始日期不可选：${startDate}`);
  }
  await sleep(250);

  await ensureAntPickerDateVisible(endDate);
  if (!clickAntDateCellInOpenDropdown(endDate)) {
    throw new Error(`非俄罗斯自选时间段结束日期不可选：${endDate}`);
  }
  await sleep(200);

  const okBtn = document.querySelector('.ant-picker-dropdown:not(.ant-picker-dropdown-hidden) .ant-picker-ok button');
  if (okBtn) {
    dispatchClick(okBtn);
    await sleep(150);
  }

  await waitUntil(() => {
    const values = readNonRuSettlementSelfDateRange();
    return values.startDate === startDate && values.endDate === endDate;
  }, 3000, `非俄罗斯自选时间段选择结果不正确：${startDate} ~ ${endDate}`);
}

async function openNonRuSettlementSelfDatePicker(picker, startInput) {
  if (getOpenAntPickerPanels().length > 0) {
    return;
  }

  const inputWrapper = startInput?.closest?.('.ant-picker-input') || null;
  const calendarIcon = picker?.querySelector?.('.ant-picker-suffix') || null;
  const targets = [inputWrapper, picker, calendarIcon, startInput].filter(Boolean);

  for (const target of targets) {
    dispatchClick(target);
    const opened = await waitForNonRuAntPickerOpen(700);
    if (opened) {
      return;
    }
  }

  throw new Error('非俄罗斯自选时间段日期选择面板未打开。');
}

async function waitForNonRuAntPickerOpen(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (getOpenAntPickerPanels().length > 0) {
      return true;
    }
    await sleep(80);
  }
  return false;
}

async function ensureAntPickerDateVisible(dateText) {
  const targetIndex = getMonthIndexFromDateText(dateText);
  if (!Number.isFinite(targetIndex)) {
    throw new Error(`非俄罗斯自选时间段日期格式非法：${dateText}`);
  }

  for (let i = 0; i < 36; i += 1) {
    if (clickAntDateCellInOpenDropdown(dateText, false)) {
      return;
    }

    const panelInfos = getOpenAntPickerPanelInfos();
    if (panelInfos.length === 0) {
      await sleep(120);
      continue;
    }

    const monthIndexes = panelInfos.map((info) => info.panelYear * 12 + (info.panelMonth - 1));
    const minMonthIndex = Math.min(...monthIndexes);
    const maxMonthIndex = Math.max(...monthIndexes);
    const goPrev = targetIndex < minMonthIndex;
    const goNext = targetIndex > maxMonthIndex;
    if (!goPrev && !goNext) {
      return;
    }

    const btn = findVisibleAntPickerNavButton(goPrev ? 'prev' : 'next');
    if (!btn) {
      break;
    }

    clickOnce(btn);
    await sleep(160);
  }

  throw new Error(`非俄罗斯自选时间段无法显示目标日期：${dateText}`);
}

function getMonthIndexFromDateText(dateText) {
  const [yText, mText] = String(dateText || '').split('-');
  const year = Number(yText);
  const month = Number(mText);
  if (!Number.isFinite(year) || !Number.isFinite(month) || month < 1 || month > 12) {
    return NaN;
  }
  return year * 12 + (month - 1);
}

function findVisibleAntPickerNavButton(direction) {
  const selector = direction === 'prev' ? '.ant-picker-header-prev-btn' : '.ant-picker-header-next-btn';
  const dropdowns = Array.from(document.querySelectorAll('.ant-picker-dropdown'))
    .filter((node) => !String(node.className || '').includes('ant-picker-dropdown-hidden') && isElementVisible(node));
  const buttons = dropdowns.flatMap((dropdown) => Array.from(dropdown.querySelectorAll(selector)));
  return buttons.find((btn) => isElementVisible(btn) && window.getComputedStyle(btn).visibility !== 'hidden') || null;
}

async function ensureAntPickerAtMonth(dateText, panelIndex = 0) {
  const [yText, mText] = String(dateText || '').split('-');
  const targetYear = Number(yText);
  const targetMonth = Number(mText);

  for (let i = 0; i < 36; i += 1) {
    const panelInfo = typeof panelIndex === 'number'
      ? (getAntPickerPanelInfoByIndex(panelIndex) || getAntPickerPanelInfoByIndex(0))
      : getNearestAntPickerPanelInfo(dateText);
    if (!panelInfo) {
      await sleep(120);
      continue;
    }

    const { panelYear, panelMonth, panelRoot } = panelInfo;
    if (panelYear === targetYear && panelMonth === targetMonth) {
      return;
    }

    const goPrev = panelYear > targetYear || (panelYear === targetYear && panelMonth > targetMonth);
    const btn = panelRoot.querySelector(goPrev ? '.ant-picker-header-prev-btn' : '.ant-picker-header-next-btn')
      || document.querySelector(goPrev ? '.ant-picker-header-prev-btn' : '.ant-picker-header-next-btn');
    if (!btn) {
      break;
    }

    clickOnce(btn);
    await sleep(120);
  }

  throw new Error(`非俄罗斯自选时间段无法切换到目标月份：${dateText}`);
}

function getNearestAntPickerPanelInfo(dateText) {
  const [yText, mText] = String(dateText || '').split('-');
  const targetYear = Number(yText);
  const targetMonth = Number(mText);
  const panels = getOpenAntPickerPanels()
    .map((panel, index) => ({ index, info: getAntPickerPanelInfoByIndex(index) }))
    .map((item) => item.info)
    .filter(Boolean);

  if (panels.length === 0) {
    return null;
  }

  const exact = panels.find((info) => info.panelYear === targetYear && info.panelMonth === targetMonth);
  if (exact) {
    return exact;
  }

  return panels[0];
}

function getOpenAntPickerPanels() {
  const dropdowns = Array.from(document.querySelectorAll('.ant-picker-dropdown'))
    .filter((node) => !String(node.className || '').includes('ant-picker-dropdown-hidden') && isElementVisible(node));
  return dropdowns.flatMap((dropdown) => Array.from(dropdown.querySelectorAll('.ant-picker-panel')))
    .filter((panel) => isElementVisible(panel));
}

function getAntPickerPanelInfoByIndex(panelIndex = 0) {
  const targetPanel = getOpenAntPickerPanels()[panelIndex] || getOpenAntPickerPanels()[0] || null;
  if (!targetPanel) {
    return null;
  }

  const yearText = textOf(targetPanel.querySelector('.ant-picker-year-btn'));
  const monthText = textOf(targetPanel.querySelector('.ant-picker-month-btn'));
  const yearMatch = yearText.match(/(\d{4})/);
  const monthNumber = parsePickerMonthText(monthText);
  if (!yearMatch || !monthNumber) {
    return null;
  }

  return {
    panelRoot: targetPanel,
    panelYear: Number(yearMatch[1]),
    panelMonth: monthNumber
  };
}

function getOpenAntPickerPanelInfos() {
  return getOpenAntPickerPanels()
    .map((panel, index) => ({ panel, index, info: getAntPickerPanelInfoByIndex(index) }))
    .map((item) => item.info)
    .filter(Boolean);
}

function clickAntDateCellIfVisible(dateText, panelIndex = 0) {
  const panel = getAntPickerPanelInfoByIndex(panelIndex)?.panelRoot;
  const scope = panel || document;
  const candidates = Array.from(scope.querySelectorAll(`td[title="${dateText}"]`));
  const cell = candidates.find((node) => {
    const className = String(node.className || '');
    return !className.includes('ant-picker-cell-disabled') && !className.includes('ant-picker-cell-hidden');
  });
  if (!cell) {
    return false;
  }

  const clickable = cell.querySelector('.ant-picker-cell-inner') || cell;
  clickOnce(clickable);
  return true;
}

function clickAntDateCellInOpenDropdown(dateText, doClick = true) {
  const dropdowns = Array.from(document.querySelectorAll('.ant-picker-dropdown'))
    .filter((node) => !String(node.className || '').includes('ant-picker-dropdown-hidden') && isElementVisible(node));
  for (const dropdown of dropdowns) {
    const candidates = Array.from(dropdown.querySelectorAll(`td[title="${dateText}"]`));
    const cell = candidates.find((node) => {
      const className = String(node.className || '');
      return className.includes('ant-picker-cell-in-view')
        && !className.includes('ant-picker-cell-disabled')
        && !className.includes('ant-picker-cell-hidden');
    });
    if (cell) {
      if (!doClick) {
        return true;
      }
      const clickable = cell.querySelector('.ant-picker-cell-inner') || cell;
      clickOnce(clickable);
      return true;
    }
  }

  return false;
}

function getNonRuSettlementSelfRangeInputs() {
  const panel = document.querySelector('[id*="panel-SELF"]') || document.body;
  const picker = panel.querySelector('#timeRange')?.closest('.ant-picker-range')
    || panel.querySelector('.ant-picker-range')
    || document.querySelector('#timeRange')?.closest('.ant-picker-range')
    || document.querySelector('.ant-picker-range');
  if (!picker) {
    return [];
  }

  return Array.from(picker.querySelectorAll('input')).slice(0, 2);
}

function readNonRuSettlementSelfDateRange() {
  const inputs = getNonRuSettlementSelfRangeInputs();
  return {
    startDate: String(inputs[0]?.value || '').trim(),
    endDate: String(inputs[1]?.value || '').trim()
  };
}

async function submitNonRuSettlementSelfRange() {
  const panel = document.querySelector('[id*="panel-SELF"]') || document.body;
  const buttons = Array.from(panel.querySelectorAll('button'));
  const submit = buttons.find((btn) => normalizeButtonText(textOf(btn), true) === '确定')
    || buttons.find((btn) => normalizeButtonText(textOf(btn), true).includes('确定'));
  if (!submit) {
    throw new Error('非俄罗斯自选时间段账单未找到“确定”按钮。');
  }

  dispatchClick(submit);
  await sleep(500);
}

async function confirmNonRuSettlementOverwriteIfPresent() {
  const deadline = Date.now() + 4000;
  while (Date.now() < deadline) {
    const modal = Array.from(document.querySelectorAll('.ant-modal-confirm, .ant-modal'))
      .find((node) => isElementVisible(node) && textOf(node).includes('已有生成记录将被清除'));
    if (!modal) {
      await sleep(150);
      continue;
    }

    const confirm = Array.from(modal.querySelectorAll('button'))
      .find((btn) => normalizeButtonText(textOf(btn), true).includes('确认'));
    if (!confirm) {
      return;
    }

    dispatchClick(confirm);
    await sleep(500);
    return;
  }
}

function findNonRuSelfBusinessDownloadTrigger() {
  const rows = Array.from(document.querySelectorAll('.ant-descriptions-row, tr'));
  const row = rows.find((item) => normalizeButtonText(textOf(item), true).includes('账务动帐')
    || normalizeButtonText(textOf(item), true).includes('账务动账'));
  if (!row) {
    return null;
  }

  return row.querySelector('button') || row.querySelector('a, [role="button"]') || row;
}

function buildDateRangePeriodTag(startDate, endDate) {
  const start = String(startDate || '').replace(/-/g, '').slice(0, 8);
  const end = String(endDate || '').replace(/-/g, '').slice(0, 8);
  return start && end ? `${start}-${end}` : (start || end || 'period');
}

function setPlainInputValue(input, value) {
  if (!input) {
    return;
  }

  input.removeAttribute('readonly');
  input.focus();
  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (descriptor && typeof descriptor.set === 'function') {
    descriptor.set.call(input, value);
  } else {
    input.value = value;
  }
  input.setAttribute('value', value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.blur();
}

function parseYearMonthTag(input) {
  const match = String(input || '').match(/^(\d{4})-(\d{2})$/);
  if (!match) {
    return null;
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(month) || month < 1 || month > 12) {
    return null;
  }

  return { year, month };
}

function monthNameFromNumber(month) {
  const names = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  return names[month - 1] || '';
}

function findNonRuMonthCard(monthName) {
  const cards = Array.from(document.querySelectorAll('.item___392iq, [class*="item"]'));
  return cards.find((card) => {
    const title = textOf(card.querySelector('.title___1kbHC, [class*="title"]'));
    return title.toLowerCase() === String(monthName || '').toLowerCase();
  }) || null;
}

function findNonRuBusinessItemRow(monthCard) {
  const rows = Array.from(monthCard.querySelectorAll('.businessItem___dvcjI, [class*="businessItem"], div'));
  const exact = rows.find((row) => textOf(row).includes('账务动账') && row.querySelector('.downloadBox___f7R3z, [class*="downloadBox"]'));
  if (exact) {
    return exact;
  }

  return rows.find((row) => row.querySelector('.downloadBox___f7R3z, [class*="downloadBox"]')) || null;
}

function readNonRuDownloadState(node) {
  const stateEl = node?.querySelector?.('.blue___1wDbi, [class*="blue"]') || node;
  return textOf(stateEl).replace(/\s+/g, '');
}

function clickNonRuDownloadTrigger(triggerNode) {
  if (!triggerNode) {
    return;
  }

  triggerNode.scrollIntoView({ block: 'center', inline: 'center' });

  const textBtn = triggerNode.querySelector('.blue___1wDbi, [class*="blue"]');
  const iconBtn = triggerNode.querySelector('.anticon-download, [aria-label="download"]');

  if (textBtn) {
    dispatchClick(textBtn);
  }
  if (iconBtn) {
    dispatchClick(iconBtn);
  }
  dispatchClick(triggerNode);
}

async function waitForNonRuDownloadReady(resolveTrigger, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastStateText = '';
  let lastStateSince = Date.now();
  while (Date.now() < deadline) {
    const triggerNode = typeof resolveTrigger === 'function' ? resolveTrigger() : null;
    if (!triggerNode) {
      await sleep(1200);
      continue;
    }

    const state = readNonRuDownloadState(triggerNode);
    const blocked = /(预约|进度|处理中|下载中|生成中)/.test(state);
    const ready = state.includes('下载') && !blocked;
    if (ready) {
      return true;
    }

    if (state !== lastStateText) {
      lastStateText = state;
      lastStateSince = Date.now();
    }

    if (/预约/.test(state) && Date.now() - lastStateSince > 12000) {
      clickNonRuDownloadTrigger(triggerNode);
      lastStateSince = Date.now();
      showFundNotice('非俄罗斯账单仍处于预约下载，已自动重试预约。');
    }

    await sleep(2000);
  }
  return false;
}

async function ensureNonRuYearSelected(targetYear) {
  const year = Number(targetYear);
  if (!Number.isFinite(year) || year < 2000) {
    return;
  }

  const readCurrentYear = () => {
    const text = textOf(document.querySelector('.selectWrapper___6rVNo .ant-select-selection-item, [class*="select"] .ant-select-selection-item'));
    const match = text.match(/(\d{4})/);
    return match ? Number(match[1]) : 0;
  };

  if (readCurrentYear() === year) {
    return;
  }

  const trigger = document.querySelector('.selectWrapper___6rVNo .ant-select, [class*="selectWrapper"] .ant-select');
  if (!trigger) {
    return;
  }

  dispatchClick(trigger);
  await sleep(250);

  const options = Array.from(document.querySelectorAll('.ant-select-item-option, .ant-select-dropdown .ant-select-item, [role="option"]'));
  const target = options.find((node) => new RegExp(`(^|\\D)${year}(\\D|$)`).test(textOf(node)));
  if (!target) {
    return;
  }

  dispatchClick(target);
  await waitUntil(() => readCurrentYear() === year, 4000, `非俄罗斯结算账单年份切换失败：${year}`);
}

function findButtonByText(root, expectedText) {
  const normalized = normalizeButtonText(expectedText, true);
  const buttons = Array.from(root?.querySelectorAll?.('button, a, span, div') || []);
  return buttons.find((el) => normalizeButtonText(textOf(el), true).includes(normalized)) || null;
}

function resolveRuSettlementPicker(strict = false) {
  const roots = Array.from(document.querySelectorAll('.fund-account-container .ait-picker-range, .ait-picker-range'));
  const candidates = roots.map((root) => {
    const inputWrappers = Array.from(root.querySelectorAll('.ait-picker-input'));
    const inputs = inputWrappers
      .map((node) => node.querySelector('input'))
      .filter((node) => Boolean(node));
    const hasSeparator = Boolean(root.querySelector('.ait-picker-separator'));
    const score = (inputs.length >= 2 ? 3 : inputs.length) + (hasSeparator ? 1 : 0);

    return {
      root,
      inputWrappers,
      inputs,
      hasSeparator,
      score
    };
  });

  const best = candidates.sort((a, b) => b.score - a.score)[0] || null;
  const valid = best && best.inputs.length >= 2 && best.inputWrappers.length >= 2;

  if (valid) {
    return {
      root: best.root,
      inputWrappers: best.inputWrappers.slice(0, 2),
      inputs: best.inputs.slice(0, 2),
      hasSeparator: best.hasSeparator
    };
  }

  const summary = candidates.slice(0, 4).map((item, idx) => ({
    idx,
    className: item.root?.className || '',
    inputs: item.inputs.length,
    wrappers: item.inputWrappers.length,
    hasSeparator: item.hasSeparator
  }));

  logRuSettlementDebug('resolveRuSettlementPicker.notComplete', {
    rootsFound: roots.length,
    candidates: summary
  });

  if (!strict) {
    return null;
  }

  throw new Error(`俄罗斯结算账单未找到完整时间选择器（需要 ait-picker-range 内两个 ait-picker-input）。候选：${JSON.stringify(summary)}`);
}

async function setRuSettlementDateRange(startDate, endDate) {
  const start = String(startDate || '').trim();
  const end = String(endDate || '').trim();
  logRuSettlementDebug('setRuSettlementDateRange.begin', { startDate: start, endDate: end });

  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    logRuSettlementDebug('setRuSettlementDateRange.skip.invalidFormat', { startDate: start, endDate: end });
    return;
  }

  const inputs = getRuSettlementRangeInputs();
  logRuSettlementDebug('setRuSettlementDateRange.inputs', {
    count: inputs.length,
    classes: inputs.map((el) => el.className || '')
  });
  if (inputs.length < 2) {
    throw new Error('俄罗斯结算账单未找到日期范围输入框。');
  }

  try {
    logRuSettlementDebug('setRuSettlementDateRange.tryPicker', {});
    await setRuSettlementDateRangeByPicker(start, end);
  } catch (_error) {
    logRuSettlementDebug('setRuSettlementDateRange.pickerFailed', {
      error: _error?.message || String(_error)
    });
    throw _error;
  }

  await waitUntil(() => {
    const values = readRuSettlementDateRangeValues();
    return values.startDate === start && values.endDate === end;
  }, 3000, `俄罗斯结算账单日期范围未生效：${start} ~ ${end}`);

  const applied = readRuSettlementDateRangeValues();
  logRuSettlementDebug('setRuSettlementDateRange.done', applied);
  showFundNotice(`俄罗斯结算日期已设置：${applied.startDate || '-'} ~ ${applied.endDate || '-'}`);
}

function getRuSettlementRangeInputs() {
  const picker = resolveRuSettlementPicker(false);
  if (!picker) {
    return [];
  }

  return picker.inputs;
}

function readRuSettlementDateRangeValues() {
  const inputs = getRuSettlementRangeInputs();
  return {
    startDate: String(inputs[0]?.value || '').trim(),
    endDate: String(inputs[1]?.value || '').trim()
  };
}

async function setRuSettlementDateRangeByPicker(startDate, endDate) {
  const picker = resolveRuSettlementPicker(true);

  logRuSettlementDebug('setRuSettlementDateRangeByPicker.openPicker.begin', {});
  await openRuSettlementDatePicker(picker);
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.openPicker.success', {});

  activateRuPickerInput(picker, 0);
  await ensurePickerAtMonth(startDate, 0);
  if (!clickDateCellIfVisible(startDate, true, 0)) {
    throw new Error(`俄罗斯结算开始日期不可选：${startDate}`);
  }
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.startDateClicked', { startDate });
  await sleep(120);
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.afterStartValues', readRuSettlementDateRangeValues());

  // After selecting start date, the picker auto-switches to end-date mode.
  // Keep using the opened panel directly and avoid re-clicking the end input.
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.autoSwitchToEnd', {});
  await ensurePickerAtMonth(endDate, 1);
  if (!clickDateCellIfVisible(endDate, true, 1)) {
    throw new Error(`俄罗斯结算结束日期不可选：${endDate}`);
  }
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.endDateClicked', { endDate });
  await sleep(160);
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.afterEndValues', readRuSettlementDateRangeValues());

  const okBtn = document.querySelector('.ait-picker-dropdown-range .ait-picker-ok button, .ait-picker-dropdown .ait-picker-ok button, .ait-picker-panel-container .ait-picker-ok button');
  if (okBtn) {
    dispatchClick(okBtn);
    logRuSettlementDebug('setRuSettlementDateRangeByPicker.okClicked', {});
    await sleep(180);
  }

  const applied = readRuSettlementDateRangeValues();
  logRuSettlementDebug('setRuSettlementDateRangeByPicker.afterPickerApply', applied);
  const startOk = String(applied.startDate || '').includes(startDate);
  const endOk = String(applied.endDate || '').includes(endDate);
  if (!startOk || !endOk) {
    throw new Error(`俄罗斯结算账单日期最终值异常：start=${applied.startDate || '-'} end=${applied.endDate || '-'}`);
  }
}

function activateRuPickerInput(pickerContext, index) {
  const wrapper = pickerContext?.inputWrappers?.[index] || null;
  const input = pickerContext?.inputs?.[index] || null;
  if (!wrapper && !input) {
    return;
  }

  const target = wrapper || input;
  if (target) {
    target.scrollIntoView({ block: 'center', inline: 'center' });
    clickOnce(target);
    dispatchClick(target);
  }

  if (input) {
    input.focus();
    clickOnce(input);
    dispatchClick(input);
  }
}

async function openRuSettlementDatePicker(pickerContextOrRoot) {
  const rangeRoot = pickerContextOrRoot?.root || pickerContextOrRoot;
  if (!rangeRoot) {
    throw new Error('俄罗斯结算账单未找到时间选择器根节点。');
  }

  const popupSelector = '.ait-picker-dropdown-range, .ait-picker-dropdown, .ait-picker-panel-container';
  const inputWrappers = pickerContextOrRoot?.inputWrappers
    || Array.from(rangeRoot.querySelectorAll('.ait-picker-input'));
  logRuSettlementDebug('openRuSettlementDatePicker.inputs', {
    count: inputWrappers.length,
    hasSeparator: Boolean(rangeRoot.querySelector('.ait-picker-separator')),
    rootClass: String(rangeRoot.className || ''),
    hasPopupBeforeClick: Boolean(document.querySelector(popupSelector))
  });
  if (inputWrappers.length === 0) {
    throw new Error('俄罗斯结算账单未找到 .ait-picker-input 节点。');
  }

  // Per page behavior: clicking .ait-picker-input is the most stable way to open the panel.
  for (let round = 0; round < 6; round += 1) {
    const target = inputWrappers[0];
    target.scrollIntoView({ block: 'center', inline: 'center' });
    logRuSettlementDebug('openRuSettlementDatePicker.round.clicking', {
      round: round + 1,
      targetClass: target.className || ''
    });

    clickOnce(target);
    dispatchClick(target);

    const inputEl = target.querySelector('input');
    if (inputEl) {
      inputEl.focus();
      clickOnce(inputEl);
      dispatchClick(inputEl);
    }

    const opened = await waitForSelectorOptional(popupSelector, 900);
    logRuSettlementDebug('openRuSettlementDatePicker.round.result', {
      round: round + 1,
      opened
    });
    if (opened) {
      return;
    }

    await sleep(220);
  }

  throw new Error('俄罗斯结算账单日期选择器未打开。');
}

function forceSetRuSettlementRangeValues(startDate, endDate) {
  const inputs = getRuSettlementRangeInputs();
  if (inputs.length < 2) {
    return;
  }

  [
    [inputs[0], startDate],
    [inputs[1], endDate]
  ].forEach(([input, value]) => {
    if (!input) {
      return;
    }

    input.removeAttribute('readonly');
    input.focus();

    const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    if (descriptor && typeof descriptor.set === 'function') {
      descriptor.set.call(input, value);
    } else {
      input.value = value;
    }

    input.setAttribute('value', value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.blur();
  });
}

async function readSettlementHistorySignatureCounts() {
  const trigger = findButtonByText(document, '查看导出历史');
  if (!trigger) {
    logRuSettlementDebug('readSettlementHistorySignatureCounts.skip.noTrigger', {});
    return new Map();
  }

  try {
    clickOnce(trigger);
    await waitForSettlementHistoryReady(6000);

    const scope = getSettlementHistoryScope();
    const rows = getSettlementHistoryRows(scope);
    const counts = new Map();

    rows.forEach((row) => {
      const signature = buildHistoryRowSignature(row);
      counts.set(signature, (counts.get(signature) || 0) + 1);
    });

    await closeHistoryDrawer();
    return counts;
  } catch (error) {
    logRuSettlementDebug('readSettlementHistorySignatureCounts.fallback.emptyBaseline', {
      error: error?.message || String(error)
    });
    return new Map();
  }
}

async function runFundRefundExport(payload) {
  return runFundExportSubmitOnly(payload);
}

async function runFundExportSubmitOnly(payload) {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(400);

  showFundNotice(`执行导出：${payload.label || ''}，计划区间 ${payload.periodTag || '-'}，页面范围 ${payload.rangeText || '-'}`);
  logNonRuFundDebug('run.start', {
    label: payload.label || '',
    periodTag: payload.periodTag || '',
    rangeText: payload.rangeText || '',
    fileType: payload.fileType || '订单明细'
  });

  await clickButtonByText('查询', true);
  logNonRuFundDebug('run.queryClicked', {});
  await sleep(1000);

  await clickButtonByText('导出明细', true, true);
  logNonRuFundDebug('run.exportClicked', {
    atMs: Date.now()
  });
  await sleep(1000);
  await waitForFundExportSubmitAck(8000);
  logNonRuFundDebug('run.exportAck', {});

  await clickButtonByText('查看导出历史', true);
  await waitForSelector('.ait-drawer.aep-drawer.ait-drawer-open', 10000);
  logNonRuFundDebug('run.historyOpened', {});

  let row;
  try {
    row = await waitForTopDownloadableHistoryRow(120000);
  } catch (error) {
    const errMsg = String(error?.message || error || '');
    const shouldSkip = errMsg.includes('导出历史第一条在超时时间内未变为可下载状态');
    if (!shouldSkip) {
      throw error;
    }

    logNonRuFundDebug('run.skip.noDownloadableFirstRow', {
      reason: errMsg.slice(0, 120)
    });
    showFundNotice(`当前区间无可下载数据，已跳过：${payload.label || payload.periodTag || payload.rangeText || ''}`);
    await closeHistoryDrawer();
    return {
      rangeText: payload.rangeText || '',
      label: payload.label || '',
      skipped: true
    };
  }

  logNonRuFundDebug('run.topRowReady', {
    rowText: textOf(row).slice(0, 120)
  });
  const downloadAction = findFundHistoryDownloadAction(row);
  if (!downloadAction) {
    logNonRuFundDebug('run.noDownloadAction', {
      rowText: textOf(row).slice(0, 120)
    });
    throw new Error('导出历史中未找到下载按钮。');
  }

  logNonRuFundDebug('run.downloadActionFound', {
    tag: String(downloadAction.tagName || '').toLowerCase(),
    className: String(downloadAction.className || ''),
    text: normalizeButtonText(textOf(downloadAction), true).slice(0, 80)
  });

  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: payload.storeTag || 'store',
      monthTag: payload.monthTag || '',
      periodTag: payload.periodTag || payload.month || '',
      regionTag: payload.regionTag || '',
      fileType: payload.fileType || '订单明细'
    }
  });

  const downloadStarted = await triggerDownloadAction(downloadAction);
  logNonRuFundDebug('run.triggerDownloadResult', {
    downloadStarted
  });
  if (!downloadStarted) {
    throw new Error('未能触发下载。');
  }

  const downloadConfirmed = await waitForNonRuDownloadConsumption(12000);
  logNonRuFundDebug('run.downloadConfirmed', {
    downloadConfirmed
  });
  if (!downloadConfirmed) {
    const strictRetryTarget = findStrictFundTopRowDownloadButton(row) || findStrictFundTopRowDownloadButton(null);
    if (strictRetryTarget) {
      logNonRuFundDebug('run.downloadRetry.strictTarget', {
        tag: String(strictRetryTarget.tagName || '').toLowerCase(),
        className: String(strictRetryTarget.className || ''),
        text: normalizeButtonText(textOf(strictRetryTarget), true).slice(0, 80)
      });
      simulateSingleUserClick(strictRetryTarget);
      await sleep(300);
      const retryConfirmed = await waitForNonRuDownloadConsumption(12000);
      logNonRuFundDebug('run.downloadRetry.confirmed', {
        retryConfirmed
      });
      if (!retryConfirmed) {
        throw new Error('已点击下载（含严格按钮重试），但未检测到浏览器开始下载任务。');
      }
    } else {
      throw new Error('已点击下载，但未检测到浏览器开始下载任务。');
    }
  }
  await sleep(1500);
  await closeHistoryDrawer();

  showFundNotice(`已发送下载命令：${payload.fileType || '订单明细'}，命名区间 ${payload.periodTag || payload.month || '-'}，区域 ${payload.regionTag || '-'}`);

  return {
    rangeText: payload.rangeText || '',
    label: payload.label || ''
  };
}

function showFundNotice(message) {
  const id = '__ae_fund_notice__';
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
  }

  const notice = document.createElement('div');
  notice.id = id;
  notice.textContent = String(message || '');
  notice.style.position = 'fixed';
  notice.style.top = '16px';
  notice.style.left = '50%';
  notice.style.transform = 'translateX(-50%)';
  notice.style.zIndex = '2147483647';
  notice.style.background = '#f0f7ff';
  notice.style.border = '1px solid #8ec5ff';
  notice.style.color = '#12467a';
  notice.style.fontSize = '13px';
  notice.style.lineHeight = '18px';
  notice.style.padding = '8px 12px';
  notice.style.borderRadius = '6px';
  notice.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.12)';
  notice.style.maxWidth = '720px';
  notice.style.wordBreak = 'break-word';

  document.body.appendChild(notice);

  window.setTimeout(() => {
    if (notice.parentNode) {
      notice.parentNode.removeChild(notice);
    }
  }, 6000);
}

function logRuSettlementDebug(step, details) {
  const payload = details && typeof details === 'object' ? details : { value: details };
  try {
    // Console debug for DevTools inspection.
    console.info(RU_SETTLEMENT_DEBUG_PREFIX, step, payload);
  } catch (_error) {
    // no-op
  }

  const shortDetails = JSON.stringify(payload || {}).slice(0, 180);
  showFundNotice(`[RU-DEBUG] ${step} ${shortDetails}`);
}

function logNonRuFundDebug(step, details) {
  const payload = details && typeof details === 'object' ? details : { value: details };
  try {
    console.info('[ae-nonru-fund-debug]', step, payload);
  } catch (_error) {
    // no-op
  }

  const shortDetails = JSON.stringify(payload || {}).slice(0, 180);
  showFundNotice(`[NONRU-DEBUG] ${step} ${shortDetails}`);
}

async function waitForFundExportSubmitAck(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const text = textOf(document.body);
    if (/(导出|提交).{0,20}(成功|已创建|已提交|稍后)/.test(text)) {
      await sleep(300);
      return;
    }
    await sleep(180);
  }

  // Fallback wait to avoid closing page too early when toast cannot be captured.
  await sleep(900);
}

async function captureFundHistoryBaseline() {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(300);
  const signatures = await readCurrentHistorySuccessSignatures();
  return {
    baselineSignatures: Array.from(signatures)
  };
}

async function readCurrentHistorySuccessSignatureCounts() {
  await clickButtonByText('查看导出历史', true);
  await waitForSelector(HISTORY_DRAWER_OPEN_SELECTOR, 10000);

  const drawer = getOpenHistoryDrawer();
  const rows = Array.from(drawer?.querySelectorAll('.ait-table-tbody tr.ait-table-row') || []);
  const counts = new Map();

  rows.forEach((row) => {
    const rowText = textOf(row);
    if (!rowText.includes('成功')) {
      return;
    }
    const signature = buildHistoryRowSignature(row);
    counts.set(signature, (counts.get(signature) || 0) + 1);
  });

  await closeHistoryDrawer();
  return counts;
}

async function downloadFundHistoryBatch(payload) {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(400);

  const baselineSet = new Set(Array.isArray(payload.baselineSignatures) ? payload.baselineSignatures : []);
  const plans = Array.isArray(payload.downloadPlans) ? payload.downloadPlans : [];

  if (plans.length === 0) {
    return {
      downloaded: 0
    };
  }

  await clickButtonByText('查看导出历史', true);
  await waitForSelector(HISTORY_DRAWER_OPEN_SELECTOR, 10000);

  const rows = await waitForLatestSuccessfulHistoryRows(baselineSet, plans.length, 180000);
  const remainingPlans = [...plans];

  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i];
    const parsedMeta = parseFundHistoryRowMeta(row);
    const plan = consumeBestMatchingPlan(remainingPlans, parsedMeta);
    const downloadBtn = row?.querySelector('button');
    if (!downloadBtn) {
      throw new Error(`导出历史中未找到下载按钮：${plan?.label || parsedMeta.rawText || 'unknown'}`);
    }

    const fileType = plan?.fileType || payload.fileType || '订单明细';
    const storeTag = plan?.storeTag || payload.storeTag || 'store';
    const monthTag = plan?.monthTag || payload.monthTag || '';
    const regionTag = plan?.regionTag || payload.regionTag || '';
    const periodTag = plan?.periodTag || payload.periodTag || payload.monthTag || '';

    await chrome.runtime.sendMessage({
      type: 'PREPARE_DOWNLOAD_RENAME',
      payload: {
        storeTag,
        monthTag,
        periodTag,
        regionTag,
        fileType
      }
    });

    clickOnce(downloadBtn);
    await sleep(250);
  }

  await closeHistoryDrawer();

  return {
    downloaded: rows.length
  };
}

function consumeBestMatchingPlan(remainingPlans, parsedMeta) {
  if (!Array.isArray(remainingPlans) || remainingPlans.length === 0) {
    return null;
  }

  let index = -1;

  if (parsedMeta?.periodTag && parsedMeta?.regionTag) {
    index = remainingPlans.findIndex((plan) => plan.periodTag === parsedMeta.periodTag && plan.regionTag === parsedMeta.regionTag);
  }

  if (index < 0 && parsedMeta?.periodTag) {
    index = remainingPlans.findIndex((plan) => plan.periodTag === parsedMeta.periodTag);
  }

  if (index < 0 && parsedMeta?.regionTag) {
    index = remainingPlans.findIndex((plan) => plan.regionTag === parsedMeta.regionTag);
  }

  if (index < 0) {
    index = 0;
  }

  const [plan] = remainingPlans.splice(index, 1);
  return plan || null;
}

function parseFundHistoryRowMeta(row) {
  const rawText = textOf(row);
  const regionTag = parseFundRegionFromText(rawText);
  const periodTag = parseFundPeriodFromRow(row);
  return {
    rawText,
    regionTag,
    periodTag
  };
}

function parseFundRegionFromText(text) {
  const t = String(text || '');

  if (t.includes('非俄罗斯') || t.includes('非俄') || /\bAEG\b/i.test(t)) {
    return '非俄罗斯';
  }

  if ((t.includes('俄罗斯') && !t.includes('非俄罗斯')) || /\bAER\b/i.test(t)) {
    return '俄罗斯';
  }

  return '';
}

function parseFundPeriodFromRow(row) {
  const cellTexts = Array.from(row?.querySelectorAll('td')).map((cell) => textOf(cell));

  for (const text of cellTexts) {
    const directPair = extractDateRangePair(text);
    if (directPair) {
      return toPeriodTag(directPair.start, directPair.end);
    }
  }

  const rowText = textOf(row);
  const fallbackPair = extractDateRangePair(rowText);
  if (fallbackPair) {
    return toPeriodTag(fallbackPair.start, fallbackPair.end);
  }

  const allDateTokens = rowText.match(/\d{4}-\d{2}-\d{2}/g) || [];
  if (allDateTokens.length < 2) {
    return '';
  }

  return toPeriodTag(allDateTokens[0], allDateTokens[1]);
}

function extractDateRangePair(text) {
  const value = String(text || '').replace(/\s+/g, ' ');
  const match = value.match(/(\d{4}-\d{2}-\d{2})\s*(?:~|至|到|—|–|-)\s*(\d{4}-\d{2}-\d{2})/);
  if (!match) {
    return null;
  }

  return {
    start: match[1],
    end: match[2]
  };
}

function toPeriodTag(startDate, endDate) {
  const startYm = String(startDate || '').slice(0, 7).replace('-', '');
  const endYm = String(endDate || '').slice(0, 7).replace('-', '');
  if (!startYm || !endYm) {
    return '';
  }
  return startYm === endYm ? startYm : `${startYm}-${endYm}`;
}

async function runJzgBillExport(payload) {
  await waitForSelector('#date', 20000);
  await sleep(250);

  const normalizedRange = normalizeJzgDateRange(payload.startDate, payload.endDate);
  logJzgDebug('runJzgBillExport.range', {
    payloadStart: payload.startDate || '',
    payloadEnd: payload.endDate || '',
    normalizedStart: normalizedRange.startDate,
    normalizedEnd: normalizedRange.endDate,
    businessToday: getBusinessYesterdayText(),
    chinaToday: getChinaTodayText()
  });

  ensureCainiaoBusinessTime();
  await setCainiaoDateRangeByPicker(normalizedRange.startDate, normalizedRange.endDate);

  const appliedRange = readCainiaoDateRangeInputs();
  logJzgDebug('runJzgBillExport.applied', {
    targetStart: normalizedRange.startDate,
    targetEnd: normalizedRange.endDate,
    appliedStart: appliedRange.startDate,
    appliedEnd: appliedRange.endDate
  });
  showCainiaoNotice(
    `日期已设置：目标 ${normalizedRange.startDate} ~ ${normalizedRange.endDate}；实际 ${appliedRange.startDate || '-'} ~ ${appliedRange.endDate || '-'}`
  );
  await sleep(350);

  await clickCainiaoSearchButton();
  showCainiaoNotice('已提交查询，请等待 1-2 秒...');
  await sleep(1500);

  if (hasCainiaoNoData()) {
    showCainiaoNotice('当前时间段查询无数据，已跳过下载。');
    return {
      rangeText: payload.rangeText || '',
      label: payload.label || '',
      skipped: true
    };
  }

  await ensureCainiaoTradingDetailTabActive();
  await clickCainiaoDownloadResultButton();
  const hasDialog = await handleCainiaoDownloadDialog();
  if (hasDialog) {
    showCainiaoNotice('已提交下载任务，请去下载结果查询里去下载到本地。');
  } else {
    showCainiaoNotice('已点击下载查询结果，请去下载结果查询里去下载到本地。');
  }
  await sleep(800);

  return {
    rangeText: payload.rangeText || '',
    label: payload.label || ''
  };
}

function normalizeJzgDateRange(startDate, endDate) {
  const start = String(startDate || '').trim();
  const end = String(endDate || '').trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    return {
      startDate: start,
      endDate: end
    };
  }

  const orderedStart = start <= end ? start : end;
  const orderedEnd = start <= end ? end : start;
  const today = getBusinessYesterdayText();
  const safeEnd = orderedEnd > today ? today : orderedEnd;
  const safeStart = orderedStart > safeEnd ? safeEnd : orderedStart;

  return {
    startDate: safeStart,
    endDate: safeEnd
  };
}

function getBusinessYesterdayText() {
  // Must match background's cap rule to avoid picker target drift.
  const now = new Date();
  const yesterdayUtcMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()) - 24 * 60 * 60 * 1000;
  const dObj = new Date(yesterdayUtcMs);
  const y = dObj.getUTCFullYear();
  const m = String(dObj.getUTCMonth() + 1).padStart(2, '0');
  const d = String(dObj.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getChinaTodayText() {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  const parts = formatter.formatToParts(new Date());
  const year = parts.find((part) => part.type === 'year')?.value || '';
  const month = parts.find((part) => part.type === 'month')?.value || '';
  const day = parts.find((part) => part.type === 'day')?.value || '';
  return `${year}-${month}-${day}`;
}

function ensureCainiaoBusinessTime() {
  const current = textOf(document.querySelector('#statType')?.closest('.cn-next-select')?.querySelector('em'));
  if (current.includes('业务时间')) {
    return;
  }
}

async function setCainiaoDateRangeByPicker(startDate, endDate) {
  const trigger = document.querySelector('#date [role="button"]') || document.querySelector('#date .cn-next-date-picker2-input-range');
  if (!trigger) {
    throw new Error('金掌柜页面未找到时间选择器。');
  }

  // Single pass: open picker -> select start/end -> return to caller and trigger page "查询".
  clickOnce(trigger);
  await waitForSelector('.cn-next-overlay-wrapper.opened .cn-next-date-picker2-overlay-range', 8000);
  logJzgDebug('picker.opened', {
    targetStart: startDate,
    targetEnd: endDate,
    visibleMonths: getCainiaoVisibleMonths()
  });

  await clickCainiaoDateInPicker(startDate);
  logJzgDebug('picker.afterStart', readCainiaoDateRangeInputs());
  await clickCainiaoDateInPicker(endDate);
  logJzgDebug('picker.afterEnd', readCainiaoDateRangeInputs());
  await sleep(220);

  if (!isCainiaoDateRangeApplied(startDate, endDate)) {
    logJzgDebug('picker.fallbackInputs.begin', {
      targetStart: startDate,
      targetEnd: endDate,
      applied: readCainiaoDateRangeInputs()
    });
    await trySetCainiaoDateRangeByInputs(startDate, endDate);
    await sleep(220);
    logJzgDebug('picker.fallbackInputs.done', readCainiaoDateRangeInputs());
  }

  if (!isCainiaoDateRangeApplied(startDate, endDate)) {
    logJzgDebug('picker.failed', {
      targetStart: startDate,
      targetEnd: endDate,
      applied: readCainiaoDateRangeInputs(),
      visibleMonths: getCainiaoVisibleMonths()
    });
    throw new Error(`金掌柜日期范围未正确设置：${startDate} ~ ${endDate}`);
  }
}

function isCainiaoDateRangeApplied(startDate, endDate) {
  const values = readCainiaoDateRangeInputs();
  return values.startDate === startDate && values.endDate === endDate;
}

function readCainiaoDateRangeInputs() {
  const root = document.querySelector('#date');
  if (!root) {
    return {
      startDate: '',
      endDate: ''
    };
  }

  const inputs = Array.from(root.querySelectorAll('input'));
  if (inputs.length < 2) {
    return {
      startDate: '',
      endDate: ''
    };
  }

  const startValue = String(inputs[0].value || '').trim();
  const endValue = String(inputs[1].value || '').trim();
  return {
    startDate: startValue,
    endDate: endValue
  };
}

async function trySetCainiaoDateRangeByInputs(startDate, endDate) {
  const root = document.querySelector('#date');
  if (!root) {
    return;
  }

  const inputs = Array.from(root.querySelectorAll('input')).filter((input) => {
    const type = String(input.getAttribute('type') || '').toLowerCase();
    return type === 'text' || type === '';
  });
  if (inputs.length < 2) {
    return;
  }

  setCainiaoInputValue(inputs[0], startDate);
  setCainiaoInputValue(inputs[1], endDate);

  inputs[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  inputs[1].dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
  inputs[0].dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  inputs[0].dispatchEvent(new KeyboardEvent('keyup', { key: 'Tab', bubbles: true }));
  inputs[1].blur();
}

function setCainiaoInputValue(input, value) {
  if (!input) {
    return;
  }

  input.removeAttribute('readonly');
  input.focus();

  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (descriptor && typeof descriptor.set === 'function') {
    descriptor.set.call(input, value);
  } else {
    input.value = value;
  }

  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

async function clickCainiaoSearchButton() {
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    const direct = document.querySelector('button[data-hottag="cn-ui.cn-filter.search"]');
    if (direct) {
      logJzgDebug('search.click', {
        source: 'data-hottag',
        text: textOf(direct)
      });
      dispatchClick(direct);
      return;
    }

    const submitBtn = Array.from(document.querySelectorAll('form[role="grid"] button[type="submit"]'))
      .find((btn) => normalizeButtonText(textOf(btn), true).includes('查询'));
    if (submitBtn) {
      logJzgDebug('search.click', {
        source: 'submit-button',
        text: textOf(submitBtn)
      });
      dispatchClick(submitBtn);
      return;
    }

    await sleep(180);
  }

  throw new Error('金掌柜页面未找到查询按钮。');
}

async function clickCainiaoDateInPicker(dateText) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dateText || ''))) {
    throw new Error(`金掌柜日期格式非法：${dateText}`);
  }

  const targetYm = Number(String(dateText).slice(0, 7).replace('-', ''));

  for (let i = 0; i < 36; i += 1) {
    const directCell = document.querySelector(`.cn-next-overlay-wrapper.opened td[title="${dateText}"]:not(.cn-next-calendar2-cell-disabled)`);
    if (directCell) {
      logJzgDebug('picker.date.hit', {
        date: dateText,
        attempt: i + 1,
        visibleMonths: getCainiaoVisibleMonths()
      });
      clickOnce(directCell.querySelector('.cn-next-calendar2-cell-inner') || directCell);
      return;
    }

    const months = getCainiaoVisibleMonths();
    if (months.length > 0) {
      const minYm = months[0];
      const maxYm = months[months.length - 1];
      if (targetYm < minYm) {
        const prevBtn = document.querySelector('.cn-next-range-picker-left .cn-next-icon-arrow-left')?.closest('button');
        if (!prevBtn) break;
        logJzgDebug('picker.nav.prev', {
          date: dateText,
          attempt: i + 1,
          visibleMonths: months
        });
        clickOnce(prevBtn);
        await sleep(140);
        continue;
      }
      if (targetYm > maxYm) {
        const nextBtn = document.querySelector('.cn-next-range-picker-right .cn-next-icon-arrow-right')?.closest('button');
        if (!nextBtn) break;
        logJzgDebug('picker.nav.next', {
          date: dateText,
          attempt: i + 1,
          visibleMonths: months
        });
        clickOnce(nextBtn);
        await sleep(140);
        continue;
      }
    }

    await sleep(140);
  }

  throw new Error(`金掌柜日期不可选：${dateText}`);
}

function logJzgDebug(step, payload) {
  try {
    console.log(`${JZG_DEBUG_PREFIX} ${step}`, payload || {});
  } catch (_err) {
    // Keep export flow alive even if console serialization fails.
  }
}

function getCainiaoVisibleMonths() {
  const months = [];
  const panels = Array.from(document.querySelectorAll('.cn-next-overlay-wrapper.opened .cn-next-calendar2-panel'));
  panels.forEach((panel) => {
    const headerButtons = Array.from(panel.querySelectorAll('.cn-next-calendar2-header-text-field button'));
    const yearText = textOf(headerButtons[0]);
    const monthText = textOf(headerButtons[1]);
    const yearMatch = yearText.match(/(\d{4})/);
    const monthMatch = monthText.match(/(\d{1,2})/);
    if (!yearMatch || !monthMatch) {
      return;
    }
    months.push(Number(`${yearMatch[1]}${String(monthMatch[1]).padStart(2, '0')}`));
  });
  return months.sort((a, b) => a - b);
}

function hasCainiaoNoData() {
  const statBlocks = Array.from(document.querySelectorAll('[class*="TableDataStatistics--element"]'));
  for (const block of statBlocks) {
    const title = textOf(block.querySelector('[class*="TableDataStatistics--title"]'));
    if (!title.includes('搜索结果数')) {
      continue;
    }
    const valueText = textOf(block.querySelector('[class*="TableDataStatistics--number"]')).replace(/,/g, '');
    const value = Number(valueText);
    if (Number.isFinite(value)) {
      return value === 0;
    }
  }

  const rowCount = document.querySelectorAll('.cn-next-tabs-tabpane.active .cn-table-body tbody tr').length;
  if (rowCount > 0) {
    return false;
  }

  const emptySelectors = [
    '.cn-next-table-empty',
    '.next-table-empty',
    '.cn-ui-empty',
    '.cn-next-empty'
  ];

  const emptyNode = emptySelectors
    .map((selector) => document.querySelector(selector))
    .find((node) => node && textOf(node));

  if (emptyNode && /(暂无数据|无数据|没有数据)/.test(textOf(emptyNode))) {
    return true;
  }

  const totalText = textOf(document.querySelector('.cn-next-pagination-total, .cn-next-pagination, .next-pagination'));
  if (/总计\s*[:：]?\s*0/.test(totalText)) {
    return true;
  }

  return false;
}

function showCainiaoNotice(message) {
  const id = '__ae_jzg_notice__';
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
  }

  const notice = document.createElement('div');
  notice.id = id;
  notice.textContent = String(message || '');
  notice.style.position = 'fixed';
  notice.style.top = '16px';
  notice.style.left = '50%';
  notice.style.transform = 'translateX(-50%)';
  notice.style.zIndex = '2147483647';
  notice.style.background = '#fff7e6';
  notice.style.border = '1px solid #ffd591';
  notice.style.color = '#ad4e00';
  notice.style.fontSize = '14px';
  notice.style.lineHeight = '20px';
  notice.style.padding = '10px 14px';
  notice.style.borderRadius = '6px';
  notice.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.12)';
  notice.style.maxWidth = '560px';
  notice.style.wordBreak = 'break-word';

  document.body.appendChild(notice);

  window.setTimeout(() => {
    if (notice.parentNode) {
      notice.parentNode.removeChild(notice);
    }
  }, 5000);
}

async function clickCainiaoDownloadResultButton() {
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    const activePane = document.querySelector('.cn-next-tabs-tabpane.active:not(.hidden)') || document;
    const exactBtn = activePane.querySelector('button[data-hottag="cn-ui.cn-table.下载查询结果"]');
    const byTextBtn = Array.from(activePane.querySelectorAll('button'))
      .find((btn) => normalizeButtonText(textOf(btn), true).includes('下载查询结果'));
    const target = exactBtn || byTextBtn;

    if (target && isCainiaoButtonClickable(target)) {
      target.scrollIntoView({ block: 'center', inline: 'center' });
      clickOnce(target);
      return;
    }

    await sleep(300);
  }

  throw new Error('未找到“下载查询结果”按钮。');
}

async function ensureCainiaoTradingDetailTabActive() {
  const activeTab = document.querySelector('.cn-next-tabs-tab.active .cn-next-tabs-tab-inner span');
  const activeText = normalizeButtonText(textOf(activeTab), true);
  if (activeText.includes('交易明细账单')) {
    return;
  }

  const tabs = Array.from(document.querySelectorAll('.cn-next-tabs-tab'));
  const detailTab = tabs.find((tab) => normalizeButtonText(textOf(tab), true).includes('交易明细账单'));
  if (detailTab) {
    dispatchClick(detailTab);
    await sleep(300);
  }
}

function isCainiaoButtonClickable(node) {
  if (!node) {
    return false;
  }

  const disabledByAttr = node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true';
  const disabledByClass = String(node.className || '').toLowerCase().includes('disabled');
  return !(disabledByAttr || disabledByClass);
}

async function handleCainiaoDownloadDialog() {
  const dialogFound = await waitForSelectorOptional('.cn-next-dialog', 7000);
  if (!dialogFound) {
    return false;
  }

  const dialog = document.querySelector('.cn-next-dialog');
  if (!dialog) {
    return false;
  }

  const checkboxInputs = Array.from(dialog.querySelectorAll('#checkbox input[type="checkbox"]'));
  checkboxInputs.forEach((input) => {
    const value = String(input.value || '');
    const shouldChecked = value === 'billTrading';
    if (Boolean(input.checked) !== shouldChecked) {
      const wrapper = input.closest('label');
      if (wrapper) {
        clickOnce(wrapper);
      }
    }
  });

  const okBtn = Array.from(dialog.querySelectorAll('button')).find((btn) => normalizeButtonText(textOf(btn), true).includes('确定'));
  if (!okBtn) {
    throw new Error('账单下载配置弹窗未找到“确定”按钮。');
  }
  await sleep(1000);
  clickOnce(okBtn);
  return true;
}

async function waitForSelectorOptional(selector, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (document.querySelector(selector)) {
      return true;
    }
    await sleep(150);
  }
  return false;
}

async function readCurrentHistorySuccessSignatures() {
  await clickButtonByText('查看导出历史', true);
  await waitForSettlementHistoryReady(10000);

  const scope = getSettlementHistoryScope();
  const rows = getSettlementHistoryRows(scope);
  const set = new Set();

  rows.forEach((row) => {
    const rowText = textOf(row);
    if (!rowText.includes('成功')) {
      return;
    }
    set.add(buildHistoryRowSignature(row));
  });

  await closeHistoryDrawer();
  return set;
}

async function waitForTopDownloadableHistoryRow(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let loop = 0;

  while (Date.now() < deadline) {
    loop += 1;
    const scope = getSettlementHistoryScope();
    if (!scope) {
      await sleep(300);
      continue;
    }

    const rows = getSettlementHistoryRows(scope);
    if (loop <= 5 || loop % 10 === 0) {
      logNonRuFundDebug('wait.loop', {
        loop,
        rows: rows.length
      });
    }
    if (rows.length === 0) {
      if (loop % 3 === 0) {
        triggerSettlementHistoryRefresh(scope);
      }
      await sleep(800);
      continue;
    }

    // Strictly monitor only the first row to avoid downloading old files from lower rows.
    const topRow = rows[0];
    const topText = textOf(topRow);
    const topIsSuccess = topText.includes('成功');
    if (loop <= 5 || loop % 10 === 0) {
      logNonRuFundDebug('wait.topStatus', {
        loop,
        topIsSuccess,
        topText: topText.slice(0, 100)
      });
    }
    if (!topIsSuccess) {
      if (loop % 2 === 0) {
        triggerSettlementHistoryRefresh(scope);
      }
      await sleep(1000);
      continue;
    }

    const action = findFundHistoryDownloadAction(topRow);
    if (!action) {
      if (loop <= 5 || loop % 10 === 0) {
        logNonRuFundDebug('wait.noAction', {
          loop,
          topText: topText.slice(0, 100)
        });
      }
      if (loop % 2 === 0) {
        triggerSettlementHistoryRefresh(scope);
      }
      await sleep(1000);
      continue;
    }

    const actionText = normalizeButtonText(textOf(action), true);
    const actionClass = String(action.className || '').toLowerCase();
    const isDisabled = action.hasAttribute('disabled')
      || action.getAttribute('aria-disabled') === 'true'
      || actionClass.includes('disabled')
      || actionClass.includes('not-allowed');
    const hasDownloadHref = Boolean(readActionDownloadUrl(action));
    const isDownloadAction = actionText.includes('下载') || hasDownloadHref;
    if (loop <= 5 || loop % 10 === 0) {
      logNonRuFundDebug('wait.actionState', {
        loop,
        actionText: actionText.slice(0, 60),
        actionClass: actionClass.slice(0, 100),
        isDisabled,
        hasDownloadHref,
        isDownloadAction
      });
    }
    if (!isDownloadAction || isDisabled) {
      if (loop % 2 === 0) {
        triggerSettlementHistoryRefresh(scope);
      }
      await sleep(1000);
      continue;
    }

    return topRow;
  }

  throw new Error('导出历史第一条在超时时间内未变为可下载状态。');
}

function findFundHistoryDownloadAction(row) {
  if (!row) {
    return null;
  }

  const directAnchor = row.querySelector('a[href*="attachment="], a[href*="download" i], a[href*=".xlsx" i], a[href*=".csv" i]');
  if (directAnchor) {
    const disabledByClass = String(directAnchor.className || '').toLowerCase().includes('disabled');
    const disabledByAria = directAnchor.getAttribute('aria-disabled') === 'true';
    if (!disabledByClass && !disabledByAria) {
      return directAnchor;
    }
  }

  const candidates = Array.from(row.querySelectorAll('button, a, [role="button"]'));
  for (const node of candidates) {
    const txt = normalizeButtonText(textOf(node), true);
    if (!txt.includes('下载')) {
      continue;
    }

    const className = String(node.className || '').toLowerCase();
    const isDisabled = node.hasAttribute('disabled')
      || node.getAttribute('aria-disabled') === 'true'
      || className.includes('disabled')
      || className.includes('not-allowed');
    if (isDisabled) {
      continue;
    }

    return node;
  }

  return null;
}

async function waitForRuFirstRowDownloadableByPopupPolling(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let round = 0;

  while (Date.now() < deadline) {
    round += 1;

    await clickButtonByText('查看导出历史', true);

    const ready = await waitForSettlementHistoryReadyOptional(6000);
    if (!ready) {
      logRuSettlementDebug('ruHistoryPolling.round.notReady', { round });
      await closeRuHistoryPopupForPolling();
      await sleep(1200);
      continue;
    }

    const modal = getOpenHistoryModal();
    const scope = modal || getSettlementHistoryScope();
    const scopeType = modal ? 'modal' : (getOpenHistoryDrawer() ? 'drawer' : 'table');
    const allRows = getRuHistoryRowsFromOpenModal(modal).length > 0
      ? getRuHistoryRowsFromOpenModal(modal)
      : getSettlementHistoryRows(scope);
    logRuSettlementDebug('ruHistoryPolling.round.scope', {
      round,
      scopeType,
      rows: allRows.length
    });

    const firstRow = getRuSettlementFirstHistoryDataRow(scope, allRows);
    if (!firstRow) {
      logRuSettlementDebug('ruHistoryPolling.round.emptyRows', { round });
      await closeRuHistoryPopupForPolling();
      await sleep(1200);
      continue;
    }

    const operationNode = findRuSettlementDownloadAction(firstRow);
    const operationCell = firstRow.querySelector('td:last-child');
    const operationText = normalizeButtonText(textOf(operationCell), true);
    const downloadUrl = operationNode ? readActionDownloadUrl(operationNode) : '';

    const canDownload = Boolean(operationNode);

    logRuSettlementDebug('ruHistoryPolling.round.firstRow', {
      round,
      scopeType,
      operationText,
      hasDownloadUrl: Boolean(downloadUrl),
      canDownload
    });

    if (canDownload) {
      return firstRow;
    }

    await closeRuHistoryPopupForPolling();
    await sleep(1200);
  }

  throw new Error('轮询导出历史超时：第一条记录未变为“下载报表”。');
}

function getRuHistoryRowsFromOpenModal(modal) {
  if (!modal) {
    return [];
  }

  const rows = Array.from(modal.querySelectorAll('.ait-table-tbody tr.ait-table-row, tbody.ait-table-tbody tr'));
  return rows.filter((row) => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 4) {
      return false;
    }
    const text = normalizeButtonText(textOf(row), true);
    return Boolean(text) && !text.includes('暂无数据') && !text.includes('nodata') && !text.includes('无数据');
  });
}

async function closeRuHistoryPopupForPolling() {
  const modalCloseBtn = document.querySelector('.ait-modal-content .ait-modal-close, .ait-modal-close');
  if (modalCloseBtn) {
    clickOnce(modalCloseBtn);
    dispatchClick(modalCloseBtn);
    try {
      await waitUntil(() => !getOpenHistoryModal() && !getOpenHistoryDrawer(), 2000, 'RU历史弹窗未关闭');
      return;
    } catch (_error) {
      // Fallback below.
    }
  }

  await forceCloseSettlementHistoryPopup();
}

function getRuSettlementFirstHistoryDataRow(scope, prefetchedRows) {
  const rows = Array.isArray(prefetchedRows) && prefetchedRows.length > 0
    ? prefetchedRows
    : getSettlementHistoryRows(scope);
  return rows.find((row) => {
    const cells = Array.from(row.querySelectorAll('td'));
    if (cells.length < 4) {
      return false;
    }

    const rowText = normalizeButtonText(textOf(row), true);
    if (!rowText || rowText.includes('暂无数据') || rowText.includes('nodata') || rowText.includes('无数据')) {
      return false;
    }

    return true;
  }) || null;
}

function findRuSettlementDownloadAction(row) {
  if (!row) {
    return null;
  }

  const cells = Array.from(row.querySelectorAll('td'));
  const operationCell = cells[cells.length - 1] || row;

  const actionNodes = Array.from(operationCell.querySelectorAll('a[href], button, [role="button"]'));
  const exact = actionNodes.find((node) => {
    const nodeText = normalizeButtonText(textOf(node), true);
    const href = String(node.getAttribute?.('href') || node.href || '').trim();
    return nodeText.includes('下载报表') || href.includes('attachment=') || href.includes('.xlsx');
  });
  if (exact) {
    return exact;
  }

  const fallback = actionNodes.find((node) => normalizeButtonText(textOf(node), true).includes('下载'));
  if (fallback) {
    return fallback;
  }

  return row.querySelector('a[href*="attachment="], a[href*=".xlsx"], a[href]');
}

async function triggerRuSettlementDownload(actionNode) {
  if (!actionNode) {
    throw new Error('未找到可触发的下载操作节点。');
  }

  const url = readActionDownloadUrl(actionNode);
  if (url) {
    const directResult = await requestBackgroundDownloadByUrl(url);
    if (directResult) {
      return;
    }

    const openTabResult = await openDownloadUrlInBackgroundTab(url);
    if (openTabResult) {
      return;
    }
  }

  // Fallback to DOM click when direct download API is not available.
  dispatchClick(actionNode);
}

async function waitForSettlementHistoryReadyOptional(timeoutMs) {
  try {
    await waitForSettlementHistoryReady(timeoutMs);
    return true;
  } catch (_error) {
    return false;
  }
}

async function forceCloseSettlementHistoryPopup() {
  await closeHistoryDrawer();

  let openDrawer = getOpenHistoryDrawer();
  let openModal = getOpenHistoryModal();
  if (!openDrawer && !openModal) {
    return;
  }

  const popupScope = openModal || openDrawer || document;

  const closeCandidates = [
    popupScope.querySelector('.ait-modal-close'),
    popupScope.querySelector('.ait-drawer-close'),
    document.querySelector('.aep-drawer .ait-drawer-close'),
    document.querySelector('.ait-drawer-close'),
    document.querySelector('.ant-modal-close'),
    document.querySelector('.ait-modal-close')
  ].filter(Boolean);

  for (const node of closeCandidates) {
    dispatchClick(node);
    await sleep(120);
    openDrawer = getOpenHistoryDrawer();
    openModal = getOpenHistoryModal();
    if (!openDrawer && !openModal) {
      return;
    }
  }

  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', bubbles: true }));

  await waitUntil(() => !getOpenHistoryDrawer() && !getOpenHistoryModal(), 1500, '导出历史弹窗未能关闭，无法继续轮询刷新。');
}

async function waitForLatestSuccessfulHistoryRows(baselineSet, expectedCount, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let loop = 0;
  while (Date.now() < deadline) {
    loop += 1;
    const scope = getSettlementHistoryScope();
    if (!scope) {
      await sleep(300);
      continue;
    }

    const rows = getSettlementHistoryRows(scope);
    const matched = [];

    for (const row of rows) {
      const rowText = textOf(row);
      if (!rowText.includes('成功')) {
        continue;
      }

      const btn = row.querySelector('button');
      if (!btn) {
        continue;
      }

      const signature = buildHistoryRowSignature(row);
      if (baselineSet && baselineSet.has(signature)) {
        continue;
      }

      const btnText = normalizeButtonText(textOf(btn), true);
      const isDisabled = btn.hasAttribute('disabled') || String(btn.className || '').toLowerCase().includes('disabled');
      if (!btnText.includes('下载') || isDisabled) {
        continue;
      }

      matched.push(row);
      if (matched.length >= expectedCount) {
        return matched;
      }
    }

    if (loop % 2 === 0) {
      triggerSettlementHistoryRefresh(scope);
    }
    await sleep(1000);
  }

  throw new Error('在导出历史中未等到足够的可下载成功记录。');
}

function buildHistoryRowSignature(row) {
  const cells = Array.from(row.querySelectorAll('td'));
  const fileName = textOf(cells[0]);
  const exportTime = textOf(cells[1]);
  return `${fileName}|${exportTime}`;
}

function triggerSettlementHistoryRefresh(scope) {
  const refreshBtn = findButtonByText(scope || document, '刷新')
    || findButtonByText(scope || document, '查询')
    || document.querySelector('.aiticon-reload, .anticon-reload')?.closest('button, a, span, div');
  if (refreshBtn) {
    clickOnce(refreshBtn);
  }
}

async function closeHistoryDrawer() {
  const closeBtn = document.querySelector(`${HISTORY_DRAWER_OPEN_SELECTOR} .ait-drawer-close`)
    || document.querySelector('.ait-drawer-close')
    || document.querySelector('.ait-modal-wrap .ait-modal-close')
    || document.querySelector('.ait-modal-root .ait-modal-close')
    || document.querySelector('.ait-modal-close');
  if (closeBtn) {
    dispatchClick(closeBtn);
  }

  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    const drawer = getOpenHistoryDrawer();
    const modal = getOpenHistoryModal();
    if (!drawer && !modal) {
      return;
    }
    await sleep(120);
  }
}

function getOpenHistoryDrawer() {
  const candidates = Array.from(document.querySelectorAll(HISTORY_DRAWER_OPEN_SELECTOR));
  if (candidates.length === 0) {
    return null;
  }

  const visible = candidates.find((el) => isElementVisible(el));
  return visible || candidates[0] || null;
}

function getOpenHistoryModal() {
  const candidates = Array.from(document.querySelectorAll(HISTORY_MODAL_OPEN_SELECTOR));
  if (candidates.length === 0) {
    return null;
  }

  const historyModal = candidates.find((el) => {
    if (!isElementVisible(el)) {
      return false;
    }
    const title = textOf(el.querySelector('.ait-modal-title, .ant-modal-title'));
    return title.includes('查看历史') || title.includes('导出历史');
  });
  if (historyModal) {
    return historyModal;
  }

  const visible = candidates.find((el) => isElementVisible(el));
  return visible || candidates[0] || null;
}

function getSettlementHistoryScope() {
  const modal = getOpenHistoryModal();
  if (modal) {
    return modal;
  }

  const drawer = getOpenHistoryDrawer();
  if (drawer) {
    return drawer;
  }

  const table = document.querySelector('.ait-table-tbody tr.ait-table-row')
    || document.querySelector('.ait-table-tbody')
    || document.querySelector('.ait-table');
  if (!table) {
    return null;
  }

  return table.closest('.ait-table-wrapper') || table.closest('.ait-table') || document.body;
}

function getSettlementHistoryRows(scope) {
  if (!scope) {
    return [];
  }

  const rows = Array.from(scope.querySelectorAll('.ait-table-tbody tr.ait-table-row'));
  if (rows.length > 0) {
    const filtered = rows
      .filter((row) => isElementVisible(row))
      .filter((row) => !isSettlementHistoryPlaceholderRow(row));
    return filtered;
  }

  const fallbackRows = Array.from(scope.querySelectorAll('table tbody tr'));
  if (fallbackRows.length === 0) {
    return [];
  }

  const filteredFallbackRows = fallbackRows
    .filter((row) => isElementVisible(row))
    .filter((row) => !isSettlementHistoryPlaceholderRow(row));
  return filteredFallbackRows;
}

function isSettlementHistoryPlaceholderRow(row) {
  if (!row) {
    return true;
  }

  const rowClass = String(row.className || '').toLowerCase();
  if (rowClass.includes('placeholder') || rowClass.includes('empty')) {
    return true;
  }

  const cells = Array.from(row.querySelectorAll('td'));
  const rowText = normalizeButtonText(textOf(row), true);
  if (cells.length <= 1 && (rowText.includes('暂无数据') || rowText.includes('nodata') || rowText.includes('无数据'))) {
    return true;
  }

  return false;
}

async function waitForSettlementHistoryReady(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (getOpenHistoryModal()) {
      return;
    }

    if (getOpenHistoryDrawer()) {
      return;
    }

    const scope = getSettlementHistoryScope();
    if (scope && getSettlementHistoryRows(scope).length > 0) {
      return;
    }

    await sleep(150);
  }

  throw new Error('等待结算账单导出历史超时（抽屉和表格均未出现）。');
}

function isElementVisible(el) {
  if (!el) {
    return false;
  }

  const style = window.getComputedStyle(el);
  if (!style || style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) {
    return false;
  }

  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

async function runExport(payload) {
  const month = String(payload.month || '').trim();
  const storeTag = String(payload.storeTag || '').trim();
  const { startText: plannedStartText, endText: plannedEndText, monthCompact } = buildMonthRange(month);

  await waitForSelector('.order-export-filters', 20000);

  await ensurePaymentTimeSelected();
  const appliedRange = await setDateRange(plannedStartText, plannedEndText);
  await chooseSelectOption('.order-export-reason-select', '对账');

  await clickButtonByText('导出订单', false, true);

  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: storeTag || 'store',
      monthTag: month,
      month: monthCompact
    }
  });

  await waitForDownloadableHistoryRow();

  return {
    rangeText: `${appliedRange.startText} - ${appliedRange.endText}`
  };
}

function buildMonthRange(month) {
  const match = month.match(/^(\d{4})-(\d{2})$/);
  if (!match) {
    throw new Error('月份格式必须是 YYYY-MM。');
  }

  const year = Number(match[1]);
  const mon = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(mon) || mon < 1 || mon > 12) {
    throw new Error('月份不合法。');
  }

  const endDay = new Date(year, mon, 0).getDate();
  const mm = String(mon).padStart(2, '0');
  return {
    startText: `${year}-${mm}-01 00:00:00`,
    endText: `${year}-${mm}-${String(endDay).padStart(2, '0')} 23:59:59`,
    monthCompact: `${year}${mm}`
  };
}

async function waitForDownloadableHistoryRow() {
  const deadline = Date.now() + HISTORY_TIMEOUT_MS;

  while (Date.now() < deadline) {
    const rows = Array.from(document.querySelectorAll('.next-table-body tr'));

    const topRow = rows[0] || null;
    if (topRow) {
      const status = readOrderHistoryStatus(topRow);
      const action = findOrderHistoryDownloadAction(topRow);
      const completed = status.includes('完成');
      if (completed && action) {
        await triggerDownloadAction(action);
        return;
      }
    }

    const refresh = document.querySelector('.order-export-refresh');
    if (refresh) {
      refresh.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    }

    await sleep(STATUS_WAIT_MS);
  }

  throw new Error('导出历史在超时时间内未出现可下载记录。');
}

async function triggerDownloadAction(action) {
  if (!action) {
    logNonRuFundDebug('trigger.skip.noAction', {});
    return false;
  }

  const strictTarget = findStrictFundTopRowDownloadButton(action?.closest?.('tr') || null);
  if (strictTarget) {
    logNonRuFundDebug('trigger.strictTarget', {
      tag: String(strictTarget.tagName || '').toLowerCase(),
      className: String(strictTarget.className || ''),
      text: normalizeButtonText(textOf(strictTarget), true).slice(0, 80)
    });
    simulateSingleUserClick(strictTarget);
    logNonRuFundDebug('trigger.domClickDispatched.strict', {});
    return true;
  }

  const clickable = resolveClickableDownloadNode(action);
  if (!clickable) {
    logNonRuFundDebug('trigger.skip.noClickable', {
      tag: String(action.tagName || '').toLowerCase(),
      className: String(action.className || ''),
      text: normalizeButtonText(textOf(action), true).slice(0, 80)
    });
    return false;
  }

  logNonRuFundDebug('trigger.clickable', {
    tag: String(clickable.tagName || '').toLowerCase(),
    className: String(clickable.className || ''),
    text: normalizeButtonText(textOf(clickable), true).slice(0, 80),
    disabled: clickable.hasAttribute('disabled') || clickable.getAttribute('aria-disabled') === 'true'
  });

  const url = readActionDownloadUrl(clickable);
  logNonRuFundDebug('trigger.url', {
    hasUrl: Boolean(url),
    urlSample: String(url || '').slice(0, 80)
  });
  if (url) {
    const directResult = await requestBackgroundDownloadByUrl(url);
    logNonRuFundDebug('trigger.directDownloadResult', {
      directResult
    });
    if (directResult) {
      return true;
    }

    const openTabResult = await openDownloadUrlInBackgroundTab(url);
    logNonRuFundDebug('trigger.openTabResult', {
      openTabResult
    });
    if (openTabResult) {
      return true;
    }
  }

  simulateSingleUserClick(clickable);
  logNonRuFundDebug('trigger.domClickDispatched', {});
  return true;
}

function resolveClickableDownloadNode(action) {
  const primary = action?.closest?.('button,a,[role="button"]') || action;
  if (primary && isElementVisible(primary)) {
    return primary;
  }

  const row = action?.closest?.('tr') || null;
  if (!row) {
    return primary || null;
  }

  const candidates = Array.from(row.querySelectorAll('td:last-child button, td:last-child a, .aep-button-group button, .aep-button-group a, [role="button"]'));
  for (const node of candidates) {
    if (!isElementVisible(node)) {
      continue;
    }

    const txt = normalizeButtonText(textOf(node), true);
    if (!txt.includes('下载')) {
      continue;
    }

    const className = String(node.className || '').toLowerCase();
    const disabled = node.hasAttribute('disabled')
      || node.getAttribute('aria-disabled') === 'true'
      || className.includes('disabled')
      || className.includes('not-allowed');
    if (!disabled) {
      return node;
    }
  }

  return primary || null;
}

function findStrictFundTopRowDownloadButton(row) {
  const targetRow = row
    || getSettlementHistoryRows(getSettlementHistoryScope())[0]
    || null;
  if (!targetRow) {
    return null;
  }

  const selectors = [
    'td.ait-table-cell-fix-right button.ait-btn.ait-btn-link',
    'td.ait-table-cell-fix-right .aep-button-group > button',
    'td:last-child .aep-button-group > button',
    'td:last-child button'
  ];

  for (const selector of selectors) {
    const nodes = Array.from(targetRow.querySelectorAll(selector));
    for (const node of nodes) {
      if (!isElementVisible(node)) {
        continue;
      }
      const txt = normalizeButtonText(textOf(node), true);
      if (!txt.includes('下载')) {
        continue;
      }
      const className = String(node.className || '').toLowerCase();
      const disabled = node.hasAttribute('disabled')
        || node.getAttribute('aria-disabled') === 'true'
        || className.includes('disabled')
        || className.includes('not-allowed');
      if (disabled) {
        continue;
      }
      return node;
    }
  }

  return null;
}

function simulateSingleUserClick(target) {
  if (!target) {
    return;
  }

  target.scrollIntoView({ block: 'center', inline: 'center' });
  const rect = target.getBoundingClientRect();
  const clientX = Math.floor(rect.left + Math.max(1, rect.width / 2));
  const clientY = Math.floor(rect.top + Math.max(1, rect.height / 2));
  const eventInit = {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX,
    clientY,
    button: 0,
    buttons: 1
  };

  if (typeof window.PointerEvent === 'function') {
    target.dispatchEvent(new PointerEvent('pointerdown', eventInit));
  }
  target.dispatchEvent(new MouseEvent('mousedown', eventInit));

  if (typeof window.PointerEvent === 'function') {
    target.dispatchEvent(new PointerEvent('pointerup', eventInit));
  }
  target.dispatchEvent(new MouseEvent('mouseup', eventInit));
  target.dispatchEvent(new MouseEvent('click', eventInit));
}

async function waitForNonRuDownloadConsumption(timeoutMs) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'WAIT_RENAME_CONSUMED_BY_TAB',
      payload: {
        timeoutMs
      }
    });
    const ok = Boolean(response?.ok && response?.consumed);
    if (!ok) {
      logNonRuFundDebug('waitDownloadConsumption.notConsumed', {
        response: JSON.stringify(response || {}).slice(0, 140)
      });
    }
    return ok;
  } catch {
    return false;
  }
}

function readActionDownloadUrl(action) {
  const anchor = action?.closest?.('a[href]') || action?.querySelector?.('a[href]') || null;
  const href = String(anchor?.getAttribute?.('href') || anchor?.href || '').trim();
  if (!href) {
    return '';
  }
  if (!/^https?:\/\//i.test(href)) {
    return '';
  }
  return href;
}

async function requestBackgroundDownloadByUrl(url) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'DIRECT_DOWNLOAD_URL',
      payload: { url }
    });
    return Boolean(response?.ok);
  } catch {
    return false;
  }
}

async function openDownloadUrlInBackgroundTab(url) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'OPEN_DOWNLOAD_URL_TAB',
      payload: { url }
    });
    return Boolean(response?.ok);
  } catch {
    return false;
  }
}

function readOrderHistoryStatus(row) {
  const wrappers = Array.from(row.querySelectorAll('td .next-table-cell-wrapper'));
  if (wrappers.length >= 7) {
    return textOf(wrappers[6]);
  }
  return textOf(row);
}

function findOrderHistoryDownloadAction(row) {
  const direct = row.querySelector('a[href*="download"], a[href*="Download"], button[title*="下载"]');
  if (direct) {
    const disabledByStyle = String(direct.getAttribute('style') || '').toLowerCase().includes('not-allowed');
    const disabledByClass = String(direct.getAttribute('class') || '').toLowerCase().includes('disabled');
    if (!(disabledByStyle || disabledByClass || direct.hasAttribute('disabled'))) {
      return direct;
    }
  }

  // Some pages wrap actionable link in parent node; click parent as fallback.
  const candidates = Array.from(row.querySelectorAll('a,button,span,div'));
  for (const el of candidates) {
    const txt = textOf(el);
    if (!txt.includes('下载')) {
      continue;
    }

    const disabledByStyle = String(el.getAttribute('style') || '').toLowerCase().includes('not-allowed');
    const disabledByClass = String(el.getAttribute('class') || '').toLowerCase().includes('disabled');
    if (disabledByStyle || disabledByClass || el.hasAttribute('disabled')) {
      continue;
    }

    return el.closest('a,button') || el;
  }

  return null;
}

async function chooseSelectOption(triggerSelector, optionText) {
  const trigger = document.querySelector(triggerSelector);
  if (!trigger) {
    throw new Error(`未找到下拉框：${triggerSelector}`);
  }

  dispatchClick(trigger);
  await sleep(250);

  const clicked = clickOptionInOverlay(optionText, triggerSelector);
  if (!clicked) {
    throw new Error(`未找到下拉项：${optionText}`);
  }

  await sleep(250);
}

function clickOptionInOverlay(text, triggerSelector = '') {
  if (triggerSelector.includes('order-export-time-select')) {
    const openedOverlay = document.querySelector('.next-overlay-wrapper.opened');
    if (openedOverlay) {
      const targetLi = openedOverlay.querySelector(`li[title="${text}"]`);
      if (targetLi) {
        dispatchClick(targetLi);
        return true;
      }

      const targetText = Array.from(openedOverlay.querySelectorAll('.next-menu-item-text'))
        .find((el) => textOf(el) === text);
      if (targetText) {
        dispatchClick(targetText.closest('li') || targetText);
        return true;
      }
    }
  }

  const roots = Array.from(document.querySelectorAll('.next-overlay-wrapper.opened, .next-overlay-wrapper, .next-overlay-inner, .next-select-menu, body'));
  for (const root of roots) {
    const candidates = Array.from(root.querySelectorAll('li, div, span, em, p, a'));
    const exact = candidates.find((el) => textOf(el) === text);
    if (exact) {
      dispatchClick(exact);
      return true;
    }

    const fuzzy = candidates.find((el) => textOf(el).includes(text));
    if (fuzzy) {
      dispatchClick(fuzzy);
      return true;
    }
  }

  return false;
}

async function setDateRange(startText, endText) {
  const plannedStartDate = startText.slice(0, 10);
  const plannedEndDate = endText.slice(0, 10);

  const [startInput, endInput] = getRangeInputs();
  if (!startInput || !endInput) {
    throw new Error('未找到日期范围输入框。');
  }

  const appliedStartDate = await pickRangeSide(startInput, plannedStartDate, '00', '00', '00', false);
  const appliedEndDate = await pickRangeSide(endInput, plannedEndDate, '23', '59', '59', true);

  await waitUntil(() => {
    const [leftWrap, rightWrap] = getRangeInputs();
    const leftInput = leftWrap?.querySelector('input');
    const rightInput = rightWrap?.querySelector('input');
    const leftValue = String(leftInput?.value || '');
    const rightValue = String(rightInput?.value || '');
    return leftValue.includes(appliedStartDate) && rightValue.includes(appliedEndDate);
  }, 8000, '日期范围写入失败');

  return {
    startText: `${appliedStartDate} 00:00:00`,
    endText: `${appliedEndDate} 23:59:59`
  };
}

function getRangeInputs() {
  return Array.from(document.querySelectorAll('.order-export-filter-time .ait-picker-range .ait-picker-input'));
}

async function pickRangeSide(inputWrapEl, dateText, hh, mm, ss, allowEndFallback) {
  const fullDateTime = `${dateText} ${hh}:${mm}:${ss}`;
  const inputEl = inputWrapEl.querySelector('input');

  dispatchClick(inputWrapEl);
  await waitForSelector('.ait-picker-dropdown-range', 8000);

  // Prefer direct text assignment to avoid unstable month-jump behavior in range picker panels.
  if (inputEl) {
    setInputDateTimeValue(inputEl, fullDateTime);
    await clickPickerConfirm(true);
    await sleep(120);

    const typedValue = String(inputEl.value || '');
    if (typedValue.includes(dateText)) {
      return dateText;
    }
  }

  await ensurePickerAtMonth(dateText);

  let appliedDate = dateText;
  const clicked = clickDateCellIfVisible(dateText);
  if (!clicked) {
    if (!allowEndFallback) {
      throw new Error(`日期不可选：${dateText}`);
    }

    const fallbackDate = findLatestSelectableDateInMonth(dateText.slice(0, 7));
    if (!fallbackDate || !clickDateCellIfVisible(fallbackDate)) {
      throw new Error(`结束日期不可选：${dateText}`);
    }
    appliedDate = fallbackDate;
  }

  await setPickerTime(hh, mm, ss);
  await clickPickerConfirm(false);
  return appliedDate;
}

async function ensurePickerAtMonth(dateText, panelIndex = 0) {
  const [yText, mText] = dateText.split('-');
  const targetYear = Number(yText);
  const targetMonth = Number(mText);

  for (let i = 0; i < 30; i += 1) {
    const panelInfo = getPickerPanelInfoByIndex(panelIndex);
    if (!panelInfo) {
      await sleep(180);
      continue;
    }

    const { panelYear, panelMonth, panelRoot } = panelInfo;
    if (panelYear === targetYear && panelMonth === targetMonth) {
      return;
    }

    const goPrev = panelYear > targetYear || (panelYear === targetYear && panelMonth > targetMonth);
    const btn = panelRoot.querySelector(goPrev ? '.ait-picker-header-prev-btn' : '.ait-picker-header-next-btn');
    if (!btn) {
      break;
    }

    dispatchClick(btn);
    await sleep(160);
  }

  throw new Error(`无法切换到目标月份：${dateText}`);
}

function getPickerPanelInfoByIndex(panelIndex = 0) {
  const panels = Array.from(document.querySelectorAll('.ait-picker-dropdown-range .ait-picker-panel'));
  const visiblePanels = panels.filter((panel) => {
    const rect = panel.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  });
  const targetPanel = visiblePanels[panelIndex] || visiblePanels[0] || panels[panelIndex] || panels[0];

  if (!targetPanel) {
    return null;
  }

  const yearText = textOf(targetPanel.querySelector('.ait-picker-year-btn'));
  const monthText = textOf(targetPanel.querySelector('.ait-picker-month-btn'));
  const yearMatch = yearText.match(/(\d{4})/);
  const monthNumber = parsePickerMonthText(monthText);
  if (!yearMatch || !monthNumber) {
    return null;
  }

  return {
    panelRoot: targetPanel,
    panelYear: Number(yearMatch[1]),
    panelMonth: monthNumber
  };
}

function parsePickerMonthText(monthText) {
  const text = String(monthText || '').trim().toLowerCase();
  const numMatch = text.match(/(\d{1,2})/);
  if (numMatch) {
    const n = Number(numMatch[1]);
    if (n >= 1 && n <= 12) {
      return n;
    }
  }

  const names = {
    jan: 1,
    january: 1,
    feb: 2,
    february: 2,
    mar: 3,
    march: 3,
    apr: 4,
    april: 4,
    may: 5,
    jun: 6,
    june: 6,
    jul: 7,
    july: 7,
    aug: 8,
    august: 8,
    sep: 9,
    sept: 9,
    september: 9,
    oct: 10,
    october: 10,
    nov: 11,
    november: 11,
    dec: 12,
    december: 12
  };

  for (const [name, value] of Object.entries(names)) {
    if (text.includes(name)) {
      return value;
    }
  }

  return 0;
}

function clickDateCellIfVisible(dateText, doClick = true, panelIndex = null) {
  const panel = typeof panelIndex === 'number' ? getPickerPanelInfoByIndex(panelIndex)?.panelRoot : null;
  const scope = panel || document;
  const candidates = Array.from(scope.querySelectorAll(`.ait-picker-dropdown-range td[title="${dateText}"], td[title="${dateText}"]`));
  const cell = candidates.find((el) => !el.classList.contains('ait-picker-cell-disabled'));
  if (!cell) {
    return false;
  }

  if (!doClick) {
    return true;
  }

  const clickable = cell.querySelector('.ait-picker-cell-inner') || cell;
  dispatchClick(clickable);
  return true;
}

function findLatestSelectableDateInMonth(monthText) {
  const cells = Array.from(document.querySelectorAll('.ait-picker-dropdown-range td[title]'));
  const dates = cells
    .filter((cell) => !cell.classList.contains('ait-picker-cell-disabled'))
    .map((cell) => String(cell.getAttribute('title') || '').trim())
    .filter((title) => /^\d{4}-\d{2}-\d{2}$/.test(title) && title.startsWith(`${monthText}-`))
    .sort();

  if (dates.length === 0) {
    return '';
  }
  return dates[dates.length - 1];
}

async function setPickerTime(hh, mm, ss) {
  const columns = Array.from(document.querySelectorAll('.ait-picker-dropdown-range .ait-picker-time-panel-column'));
  if (columns.length < 3) {
    return;
  }

  clickTimeColumnValue(columns[0], hh);
  clickTimeColumnValue(columns[1], mm);
  clickTimeColumnValue(columns[2], ss);
  await sleep(120);
}

function clickTimeColumnValue(columnEl, valueText) {
  const items = Array.from(columnEl.querySelectorAll('.ait-picker-time-panel-cell'));
  const target = items.find((item) => textOf(item.querySelector('.ait-picker-time-panel-cell-inner')) === valueText);
  if (target) {
    dispatchClick(target);
  }
}

async function clickPickerConfirm(allowDisabled) {
  const okBtn = document.querySelector('.ait-picker-dropdown-range .ait-picker-ok button');
  if (!okBtn) {
    throw new Error('未找到时间选择器确认按钮。');
  }

  if (!allowDisabled) {
    await waitUntil(() => !okBtn.disabled, 4000, '确认按钮未激活');
  }
  dispatchClick(okBtn);
  await sleep(220);
}

function setInputDateTimeValue(input, value) {
  input.removeAttribute('readonly');
  input.focus();

  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (descriptor && typeof descriptor.set === 'function') {
    descriptor.set.call(input, value);
  } else {
    input.value = value;
  }

  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
  input.blur();
}

async function ensurePaymentTimeSelected() {
  const labelText = readTimeBasisText();
  if (labelText.includes('付款时间')) {
    return;
  }

  const trigger = document.querySelector('.order-export-time-select')
    || document.querySelector('.order-export-filter-time .next-select');
  if (!trigger) {
    throw new Error('未找到时间口径下拉框。');
  }

  dispatchClick(trigger);
  await sleep(220);

  const clicked = clickOptionInOverlay('付款时间', 'order-export-time-select');
  if (!clicked) {
    throw new Error('未找到“付款时间”选项。');
  }

  await waitUntil(() => {
    const text = readTimeBasisText();
    return text.includes('付款时间');
  }, 5000, '未成功切换到付款时间');
}

function readTimeBasisText() {
  const em = document.querySelector('.order-export-time-select .next-select-values em');
  const emText = textOf(em);
  if (emText) {
    return emText;
  }

  const input = document.querySelector('.order-export-time-select input[role="combobox"]');
  const ariaText = String(input?.getAttribute('aria-valuetext') || '').trim();
  if (ariaText) {
    return ariaText;
  }

  return textOf(document.querySelector('.order-export-time-select .next-input-text-field'));
}

async function clickButtonByText(buttonText, normalizeSpace, singleClick = false) {
  const deadline = Date.now() + 10000;
  const expected = normalizeButtonText(buttonText, normalizeSpace);

  while (Date.now() < deadline) {
    const buttons = Array.from(document.querySelectorAll('button'));
    const target = buttons.find((btn) => {
      const current = normalizeButtonText(textOf(btn), normalizeSpace);
      return current.includes(expected);
    });
    if (target) {
      if (singleClick) {
        clickOnce(target);
      } else {
        dispatchClick(target);
      }
      return;
    }
    await sleep(300);
  }

  throw new Error(`未找到按钮：${buttonText}`);
}

function normalizeButtonText(text, normalizeSpace) {
  const base = String(text || '').trim();
  if (!normalizeSpace) {
    return base;
  }
  return base.replace(/\s+/g, '');
}

async function waitForSelector(selector, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (document.querySelector(selector)) {
      return;
    }
    await sleep(150);
  }
  const currentUrl = String(location.href || '');
  const bodyHint = textOf(document.body).slice(0, 80);
  throw new Error(`等待元素超时：${selector}；页面：${currentUrl}；页面文本片段：${bodyHint}`);
}

function textOf(el) {
  return String(el?.textContent || '').trim();
}

async function waitUntil(checker, timeoutMs, timeoutMessage) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (checker()) {
      return;
    }
    await sleep(120);
  }
  throw new Error(timeoutMessage);
}

function dispatchClick(el) {
  if (!el) return;
  if (typeof el.click === 'function') {
    el.click();
  }
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

function clickOnce(el) {
  if (!el) return;
  if (typeof el.click === 'function') {
    el.click();
    return;
  }
  el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
