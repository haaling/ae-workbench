const STATUS_WAIT_MS = 4000;
const HISTORY_TIMEOUT_MS = 4 * 60 * 1000;
const JZG_DEBUG_PREFIX = '[ae-jzg-debug]';
let jzgExportInProgress = false;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'START_ORDER_LIST_EXPORT') {
    void runExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_FUND_DETAILS_EXPORT') {
    void runFundDetailsExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_FUND_REFUND_EXPORT') {
    void runFundRefundExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'CAPTURE_FUND_HISTORY_BASELINE') {
    void captureFundHistoryBaseline()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'DOWNLOAD_FUND_HISTORY_BATCH') {
    void downloadFundHistoryBatch(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

    return true;
  }

  if (message?.type === 'START_JZG_BILL_EXPORT') {
    if (jzgExportInProgress) {
      logJzgDebug('guard.duplicateStartBlocked', {
        reason: 'jzgExportInProgress'
      });
      sendResponse({ ok: true, skipped: true, reason: 'JZG export already running in this page' });
      return;
    }

    jzgExportInProgress = true;
    void runJzgBillExport(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }))
      .finally(() => {
        jzgExportInProgress = false;
      });

    return true;
  }
});

async function runFundDetailsExport(payload) {
  return runFundExportSubmitOnly(payload);
}

async function runFundRefundExport(payload) {
  return runFundExportSubmitOnly(payload);
}

async function runFundExportSubmitOnly(payload) {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(400);

  showFundNotice(`执行导出：${payload.label || ''}，计划区间 ${payload.periodTag || '-'}，页面范围 ${payload.rangeText || '-'}`);

  const baselineCounts = await readCurrentHistorySuccessSignatureCounts();

  await clickButtonByText('查询', true);
  await sleep(700);

  await clickButtonByText('导出明细', true, true);
  await waitForFundExportSubmitAck(8000);

  await clickButtonByText('查看导出历史', true);
  await waitForSelector('.ait-drawer.aep-drawer.ait-drawer-open', 10000);

  const row = await waitForTopDownloadableHistoryRow(baselineCounts, 120000);
  const parsedMeta = parseFundHistoryRowMeta(row);
  const downloadBtn = row.querySelector('button');
  if (!downloadBtn) {
    throw new Error('导出历史中未找到下载按钮。');
  }

  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: payload.storeTag || 'store',
      monthTag: payload.monthTag || '',
      periodTag: payload.periodTag || payload.month || '',
      regionTag: payload.regionTag || '',
      fileType: payload.fileType || '订单明细'
    }
  });

  clickOnce(downloadBtn);
  await sleep(300);
  await closeHistoryDrawer();

  showFundNotice(`已触发下载：${payload.fileType || '订单明细'}，命名区间 ${payload.periodTag || payload.month || '-'}，区域 ${payload.regionTag || '-'}`);

  return {
    rangeText: payload.rangeText || '',
    label: payload.label || ''
  };
}

function showFundNotice(message) {
  const id = '__ae_fund_notice__';
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
  }

  const notice = document.createElement('div');
  notice.id = id;
  notice.textContent = String(message || '');
  notice.style.position = 'fixed';
  notice.style.top = '16px';
  notice.style.left = '50%';
  notice.style.transform = 'translateX(-50%)';
  notice.style.zIndex = '2147483647';
  notice.style.background = '#f0f7ff';
  notice.style.border = '1px solid #8ec5ff';
  notice.style.color = '#12467a';
  notice.style.fontSize = '13px';
  notice.style.lineHeight = '18px';
  notice.style.padding = '8px 12px';
  notice.style.borderRadius = '6px';
  notice.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.12)';
  notice.style.maxWidth = '720px';
  notice.style.wordBreak = 'break-word';

  document.body.appendChild(notice);

  window.setTimeout(() => {
    if (notice.parentNode) {
      notice.parentNode.removeChild(notice);
    }
  }, 6000);
}

async function waitForFundExportSubmitAck(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const text = textOf(document.body);
    if (/(导出|提交).{0,20}(成功|已创建|已提交|稍后)/.test(text)) {
      await sleep(300);
      return;
    }
    await sleep(180);
  }

  // Fallback wait to avoid closing page too early when toast cannot be captured.
  await sleep(900);
}

async function captureFundHistoryBaseline() {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(300);
  const signatures = await readCurrentHistorySuccessSignatures();
  return {
    baselineSignatures: Array.from(signatures)
  };
}

async function readCurrentHistorySuccessSignatureCounts() {
  await clickButtonByText('查看导出历史', true);
  await waitForSelector('.ait-drawer.aep-drawer.ait-drawer-open', 10000);

  const drawer = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open');
  const rows = Array.from(drawer?.querySelectorAll('.ait-table-tbody tr.ait-table-row') || []);
  const counts = new Map();

  rows.forEach((row) => {
    const rowText = textOf(row);
    if (!rowText.includes('成功')) {
      return;
    }
    const signature = buildHistoryRowSignature(row);
    counts.set(signature, (counts.get(signature) || 0) + 1);
  });

  await closeHistoryDrawer();
  return counts;
}

async function downloadFundHistoryBatch(payload) {
  await waitForSelector('.ait-pro-query-filter, .btn-group', 20000);
  await sleep(400);

  const baselineSet = new Set(Array.isArray(payload.baselineSignatures) ? payload.baselineSignatures : []);
  const plans = Array.isArray(payload.downloadPlans) ? payload.downloadPlans : [];

  if (plans.length === 0) {
    return {
      downloaded: 0
    };
  }

  await clickButtonByText('查看导出历史', true);
  await waitForSelector('.ait-drawer.aep-drawer.ait-drawer-open', 10000);

  const rows = await waitForLatestSuccessfulHistoryRows(baselineSet, plans.length, 180000);
  const remainingPlans = [...plans];

  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i];
    const parsedMeta = parseFundHistoryRowMeta(row);
    const plan = consumeBestMatchingPlan(remainingPlans, parsedMeta);
    const downloadBtn = row?.querySelector('button');
    if (!downloadBtn) {
      throw new Error(`导出历史中未找到下载按钮：${plan?.label || parsedMeta.rawText || 'unknown'}`);
    }

    const fileType = plan?.fileType || payload.fileType || '订单明细';
    const storeTag = plan?.storeTag || payload.storeTag || 'store';
    const monthTag = plan?.monthTag || payload.monthTag || '';
    const regionTag = plan?.regionTag || payload.regionTag || '';
    const periodTag = plan?.periodTag || payload.periodTag || payload.monthTag || '';

    await chrome.runtime.sendMessage({
      type: 'PREPARE_DOWNLOAD_RENAME',
      payload: {
        storeTag,
        monthTag,
        periodTag,
        regionTag,
        fileType
      }
    });

    clickOnce(downloadBtn);
    await sleep(250);
  }

  await closeHistoryDrawer();

  return {
    downloaded: rows.length
  };
}

function consumeBestMatchingPlan(remainingPlans, parsedMeta) {
  if (!Array.isArray(remainingPlans) || remainingPlans.length === 0) {
    return null;
  }

  let index = -1;

  if (parsedMeta?.periodTag && parsedMeta?.regionTag) {
    index = remainingPlans.findIndex((plan) => plan.periodTag === parsedMeta.periodTag && plan.regionTag === parsedMeta.regionTag);
  }

  if (index < 0 && parsedMeta?.periodTag) {
    index = remainingPlans.findIndex((plan) => plan.periodTag === parsedMeta.periodTag);
  }

  if (index < 0 && parsedMeta?.regionTag) {
    index = remainingPlans.findIndex((plan) => plan.regionTag === parsedMeta.regionTag);
  }

  if (index < 0) {
    index = 0;
  }

  const [plan] = remainingPlans.splice(index, 1);
  return plan || null;
}

function parseFundHistoryRowMeta(row) {
  const rawText = textOf(row);
  const regionTag = parseFundRegionFromText(rawText);
  const periodTag = parseFundPeriodFromRow(row);
  return {
    rawText,
    regionTag,
    periodTag
  };
}

function parseFundRegionFromText(text) {
  const t = String(text || '');

  if (t.includes('非俄罗斯') || t.includes('非俄') || /\bAEG\b/i.test(t)) {
    return '非俄罗斯';
  }

  if ((t.includes('俄罗斯') && !t.includes('非俄罗斯')) || /\bAER\b/i.test(t)) {
    return '俄罗斯';
  }

  return '';
}

function parseFundPeriodFromRow(row) {
  const cellTexts = Array.from(row?.querySelectorAll('td')).map((cell) => textOf(cell));

  for (const text of cellTexts) {
    const directPair = extractDateRangePair(text);
    if (directPair) {
      return toPeriodTag(directPair.start, directPair.end);
    }
  }

  const rowText = textOf(row);
  const fallbackPair = extractDateRangePair(rowText);
  if (fallbackPair) {
    return toPeriodTag(fallbackPair.start, fallbackPair.end);
  }

  const allDateTokens = rowText.match(/\d{4}-\d{2}-\d{2}/g) || [];
  if (allDateTokens.length < 2) {
    return '';
  }

  return toPeriodTag(allDateTokens[0], allDateTokens[1]);
}

function extractDateRangePair(text) {
  const value = String(text || '').replace(/\s+/g, ' ');
  const match = value.match(/(\d{4}-\d{2}-\d{2})\s*(?:~|至|到|—|–|-)\s*(\d{4}-\d{2}-\d{2})/);
  if (!match) {
    return null;
  }

  return {
    start: match[1],
    end: match[2]
  };
}

function toPeriodTag(startDate, endDate) {
  const startYm = String(startDate || '').slice(0, 7).replace('-', '');
  const endYm = String(endDate || '').slice(0, 7).replace('-', '');
  if (!startYm || !endYm) {
    return '';
  }
  return startYm === endYm ? startYm : `${startYm}-${endYm}`;
}

async function runJzgBillExport(payload) {
  await waitForSelector('#date', 20000);
  await sleep(250);

  const normalizedRange = normalizeJzgDateRange(payload.startDate, payload.endDate);
  logJzgDebug('runJzgBillExport.range', {
    payloadStart: payload.startDate || '',
    payloadEnd: payload.endDate || '',
    normalizedStart: normalizedRange.startDate,
    normalizedEnd: normalizedRange.endDate,
    businessToday: getBusinessYesterdayText(),
    chinaToday: getChinaTodayText()
  });

  ensureCainiaoBusinessTime();
  await setCainiaoDateRangeByPicker(normalizedRange.startDate, normalizedRange.endDate);

  const appliedRange = readCainiaoDateRangeInputs();
  logJzgDebug('runJzgBillExport.applied', {
    targetStart: normalizedRange.startDate,
    targetEnd: normalizedRange.endDate,
    appliedStart: appliedRange.startDate,
    appliedEnd: appliedRange.endDate
  });
  showCainiaoNotice(
    `日期已设置：目标 ${normalizedRange.startDate} ~ ${normalizedRange.endDate}；实际 ${appliedRange.startDate || '-'} ~ ${appliedRange.endDate || '-'}`
  );
  await sleep(350);

  await clickCainiaoSearchButton();
  showCainiaoNotice('已提交查询，请等待 1-2 秒...');
  await sleep(1500);

  if (hasCainiaoNoData()) {
    showCainiaoNotice('当前时间段查询无数据，已跳过下载。');
    return {
      rangeText: payload.rangeText || '',
      label: payload.label || '',
      skipped: true
    };
  }

  await ensureCainiaoTradingDetailTabActive();
  await clickCainiaoDownloadResultButton();
  const hasDialog = await handleCainiaoDownloadDialog();
  if (hasDialog) {
    showCainiaoNotice('已提交下载任务，请去下载结果查询里去下载到本地。');
  } else {
    showCainiaoNotice('已点击下载查询结果，请去下载结果查询里去下载到本地。');
  }
  await sleep(800);

  return {
    rangeText: payload.rangeText || '',
    label: payload.label || ''
  };
}

function normalizeJzgDateRange(startDate, endDate) {
  const start = String(startDate || '').trim();
  const end = String(endDate || '').trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    return {
      startDate: start,
      endDate: end
    };
  }

  const orderedStart = start <= end ? start : end;
  const orderedEnd = start <= end ? end : start;
  const today = getBusinessYesterdayText();
  const safeEnd = orderedEnd > today ? today : orderedEnd;
  const safeStart = orderedStart > safeEnd ? safeEnd : orderedStart;

  return {
    startDate: safeStart,
    endDate: safeEnd
  };
}

function getBusinessYesterdayText() {
  // Must match background's cap rule to avoid picker target drift.
  const now = new Date();
  const yesterdayUtcMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()) - 24 * 60 * 60 * 1000;
  const dObj = new Date(yesterdayUtcMs);
  const y = dObj.getUTCFullYear();
  const m = String(dObj.getUTCMonth() + 1).padStart(2, '0');
  const d = String(dObj.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getChinaTodayText() {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  const parts = formatter.formatToParts(new Date());
  const year = parts.find((part) => part.type === 'year')?.value || '';
  const month = parts.find((part) => part.type === 'month')?.value || '';
  const day = parts.find((part) => part.type === 'day')?.value || '';
  return `${year}-${month}-${day}`;
}

function ensureCainiaoBusinessTime() {
  const current = textOf(document.querySelector('#statType')?.closest('.cn-next-select')?.querySelector('em'));
  if (current.includes('业务时间')) {
    return;
  }
}

async function setCainiaoDateRangeByPicker(startDate, endDate) {
  const trigger = document.querySelector('#date [role="button"]') || document.querySelector('#date .cn-next-date-picker2-input-range');
  if (!trigger) {
    throw new Error('金掌柜页面未找到时间选择器。');
  }

  // Single pass: open picker -> select start/end -> return to caller and trigger page "查询".
  clickOnce(trigger);
  await waitForSelector('.cn-next-overlay-wrapper.opened .cn-next-date-picker2-overlay-range', 8000);
  logJzgDebug('picker.opened', {
    targetStart: startDate,
    targetEnd: endDate,
    visibleMonths: getCainiaoVisibleMonths()
  });

  await clickCainiaoDateInPicker(startDate);
  logJzgDebug('picker.afterStart', readCainiaoDateRangeInputs());
  await clickCainiaoDateInPicker(endDate);
  logJzgDebug('picker.afterEnd', readCainiaoDateRangeInputs());
  await sleep(220);

  if (!isCainiaoDateRangeApplied(startDate, endDate)) {
    logJzgDebug('picker.fallbackInputs.begin', {
      targetStart: startDate,
      targetEnd: endDate,
      applied: readCainiaoDateRangeInputs()
    });
    await trySetCainiaoDateRangeByInputs(startDate, endDate);
    await sleep(220);
    logJzgDebug('picker.fallbackInputs.done', readCainiaoDateRangeInputs());
  }

  if (!isCainiaoDateRangeApplied(startDate, endDate)) {
    logJzgDebug('picker.failed', {
      targetStart: startDate,
      targetEnd: endDate,
      applied: readCainiaoDateRangeInputs(),
      visibleMonths: getCainiaoVisibleMonths()
    });
    throw new Error(`金掌柜日期范围未正确设置：${startDate} ~ ${endDate}`);
  }
}

function isCainiaoDateRangeApplied(startDate, endDate) {
  const values = readCainiaoDateRangeInputs();
  return values.startDate === startDate && values.endDate === endDate;
}

function readCainiaoDateRangeInputs() {
  const root = document.querySelector('#date');
  if (!root) {
    return {
      startDate: '',
      endDate: ''
    };
  }

  const inputs = Array.from(root.querySelectorAll('input'));
  if (inputs.length < 2) {
    return {
      startDate: '',
      endDate: ''
    };
  }

  const startValue = String(inputs[0].value || '').trim();
  const endValue = String(inputs[1].value || '').trim();
  return {
    startDate: startValue,
    endDate: endValue
  };
}

async function trySetCainiaoDateRangeByInputs(startDate, endDate) {
  const root = document.querySelector('#date');
  if (!root) {
    return;
  }

  const inputs = Array.from(root.querySelectorAll('input')).filter((input) => {
    const type = String(input.getAttribute('type') || '').toLowerCase();
    return type === 'text' || type === '';
  });
  if (inputs.length < 2) {
    return;
  }

  setCainiaoInputValue(inputs[0], startDate);
  setCainiaoInputValue(inputs[1], endDate);

  inputs[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  inputs[1].dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
  inputs[0].dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  inputs[0].dispatchEvent(new KeyboardEvent('keyup', { key: 'Tab', bubbles: true }));
  inputs[1].blur();
}

function setCainiaoInputValue(input, value) {
  if (!input) {
    return;
  }

  input.removeAttribute('readonly');
  input.focus();

  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (descriptor && typeof descriptor.set === 'function') {
    descriptor.set.call(input, value);
  } else {
    input.value = value;
  }

  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

async function clickCainiaoSearchButton() {
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    const direct = document.querySelector('button[data-hottag="cn-ui.cn-filter.search"]');
    if (direct) {
      logJzgDebug('search.click', {
        source: 'data-hottag',
        text: textOf(direct)
      });
      dispatchClick(direct);
      return;
    }

    const submitBtn = Array.from(document.querySelectorAll('form[role="grid"] button[type="submit"]'))
      .find((btn) => normalizeButtonText(textOf(btn), true).includes('查询'));
    if (submitBtn) {
      logJzgDebug('search.click', {
        source: 'submit-button',
        text: textOf(submitBtn)
      });
      dispatchClick(submitBtn);
      return;
    }

    await sleep(180);
  }

  throw new Error('金掌柜页面未找到查询按钮。');
}

async function clickCainiaoDateInPicker(dateText) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dateText || ''))) {
    throw new Error(`金掌柜日期格式非法：${dateText}`);
  }

  const targetYm = Number(String(dateText).slice(0, 7).replace('-', ''));

  for (let i = 0; i < 36; i += 1) {
    const directCell = document.querySelector(`.cn-next-overlay-wrapper.opened td[title="${dateText}"]:not(.cn-next-calendar2-cell-disabled)`);
    if (directCell) {
      logJzgDebug('picker.date.hit', {
        date: dateText,
        attempt: i + 1,
        visibleMonths: getCainiaoVisibleMonths()
      });
      clickOnce(directCell.querySelector('.cn-next-calendar2-cell-inner') || directCell);
      return;
    }

    const months = getCainiaoVisibleMonths();
    if (months.length > 0) {
      const minYm = months[0];
      const maxYm = months[months.length - 1];
      if (targetYm < minYm) {
        const prevBtn = document.querySelector('.cn-next-range-picker-left .cn-next-icon-arrow-left')?.closest('button');
        if (!prevBtn) break;
        logJzgDebug('picker.nav.prev', {
          date: dateText,
          attempt: i + 1,
          visibleMonths: months
        });
        clickOnce(prevBtn);
        await sleep(140);
        continue;
      }
      if (targetYm > maxYm) {
        const nextBtn = document.querySelector('.cn-next-range-picker-right .cn-next-icon-arrow-right')?.closest('button');
        if (!nextBtn) break;
        logJzgDebug('picker.nav.next', {
          date: dateText,
          attempt: i + 1,
          visibleMonths: months
        });
        clickOnce(nextBtn);
        await sleep(140);
        continue;
      }
    }

    await sleep(140);
  }

  throw new Error(`金掌柜日期不可选：${dateText}`);
}

function logJzgDebug(step, payload) {
  try {
    console.log(`${JZG_DEBUG_PREFIX} ${step}`, payload || {});
  } catch (_err) {
    // Keep export flow alive even if console serialization fails.
  }
}

function getCainiaoVisibleMonths() {
  const months = [];
  const panels = Array.from(document.querySelectorAll('.cn-next-overlay-wrapper.opened .cn-next-calendar2-panel'));
  panels.forEach((panel) => {
    const headerButtons = Array.from(panel.querySelectorAll('.cn-next-calendar2-header-text-field button'));
    const yearText = textOf(headerButtons[0]);
    const monthText = textOf(headerButtons[1]);
    const yearMatch = yearText.match(/(\d{4})/);
    const monthMatch = monthText.match(/(\d{1,2})/);
    if (!yearMatch || !monthMatch) {
      return;
    }
    months.push(Number(`${yearMatch[1]}${String(monthMatch[1]).padStart(2, '0')}`));
  });
  return months.sort((a, b) => a - b);
}

function hasCainiaoNoData() {
  const statBlocks = Array.from(document.querySelectorAll('[class*="TableDataStatistics--element"]'));
  for (const block of statBlocks) {
    const title = textOf(block.querySelector('[class*="TableDataStatistics--title"]'));
    if (!title.includes('搜索结果数')) {
      continue;
    }
    const valueText = textOf(block.querySelector('[class*="TableDataStatistics--number"]')).replace(/,/g, '');
    const value = Number(valueText);
    if (Number.isFinite(value)) {
      return value === 0;
    }
  }

  const rowCount = document.querySelectorAll('.cn-next-tabs-tabpane.active .cn-table-body tbody tr').length;
  if (rowCount > 0) {
    return false;
  }

  const emptySelectors = [
    '.cn-next-table-empty',
    '.next-table-empty',
    '.cn-ui-empty',
    '.cn-next-empty'
  ];

  const emptyNode = emptySelectors
    .map((selector) => document.querySelector(selector))
    .find((node) => node && textOf(node));

  if (emptyNode && /(暂无数据|无数据|没有数据)/.test(textOf(emptyNode))) {
    return true;
  }

  const totalText = textOf(document.querySelector('.cn-next-pagination-total, .cn-next-pagination, .next-pagination'));
  if (/总计\s*[:：]?\s*0/.test(totalText)) {
    return true;
  }

  return false;
}

function showCainiaoNotice(message) {
  const id = '__ae_jzg_notice__';
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
  }

  const notice = document.createElement('div');
  notice.id = id;
  notice.textContent = String(message || '');
  notice.style.position = 'fixed';
  notice.style.top = '16px';
  notice.style.left = '50%';
  notice.style.transform = 'translateX(-50%)';
  notice.style.zIndex = '2147483647';
  notice.style.background = '#fff7e6';
  notice.style.border = '1px solid #ffd591';
  notice.style.color = '#ad4e00';
  notice.style.fontSize = '14px';
  notice.style.lineHeight = '20px';
  notice.style.padding = '10px 14px';
  notice.style.borderRadius = '6px';
  notice.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.12)';
  notice.style.maxWidth = '560px';
  notice.style.wordBreak = 'break-word';

  document.body.appendChild(notice);

  window.setTimeout(() => {
    if (notice.parentNode) {
      notice.parentNode.removeChild(notice);
    }
  }, 5000);
}

async function clickCainiaoDownloadResultButton() {
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    const activePane = document.querySelector('.cn-next-tabs-tabpane.active:not(.hidden)') || document;
    const exactBtn = activePane.querySelector('button[data-hottag="cn-ui.cn-table.下载查询结果"]');
    const byTextBtn = Array.from(activePane.querySelectorAll('button'))
      .find((btn) => normalizeButtonText(textOf(btn), true).includes('下载查询结果'));
    const target = exactBtn || byTextBtn;

    if (target && isCainiaoButtonClickable(target)) {
      target.scrollIntoView({ block: 'center', inline: 'center' });
      clickOnce(target);
      return;
    }

    await sleep(300);
  }

  throw new Error('未找到“下载查询结果”按钮。');
}

async function ensureCainiaoTradingDetailTabActive() {
  const activeTab = document.querySelector('.cn-next-tabs-tab.active .cn-next-tabs-tab-inner span');
  const activeText = normalizeButtonText(textOf(activeTab), true);
  if (activeText.includes('交易明细账单')) {
    return;
  }

  const tabs = Array.from(document.querySelectorAll('.cn-next-tabs-tab'));
  const detailTab = tabs.find((tab) => normalizeButtonText(textOf(tab), true).includes('交易明细账单'));
  if (detailTab) {
    dispatchClick(detailTab);
    await sleep(300);
  }
}

function isCainiaoButtonClickable(node) {
  if (!node) {
    return false;
  }

  const disabledByAttr = node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true';
  const disabledByClass = String(node.className || '').toLowerCase().includes('disabled');
  return !(disabledByAttr || disabledByClass);
}

async function handleCainiaoDownloadDialog() {
  const dialogFound = await waitForSelectorOptional('.cn-next-dialog', 7000);
  if (!dialogFound) {
    return false;
  }

  const dialog = document.querySelector('.cn-next-dialog');
  if (!dialog) {
    return false;
  }

  const checkboxInputs = Array.from(dialog.querySelectorAll('#checkbox input[type="checkbox"]'));
  checkboxInputs.forEach((input) => {
    const value = String(input.value || '');
    const shouldChecked = value === 'billTrading';
    if (Boolean(input.checked) !== shouldChecked) {
      const wrapper = input.closest('label');
      if (wrapper) {
        clickOnce(wrapper);
      }
    }
  });

  const okBtn = Array.from(dialog.querySelectorAll('button')).find((btn) => normalizeButtonText(textOf(btn), true).includes('确定'));
  if (!okBtn) {
    throw new Error('账单下载配置弹窗未找到“确定”按钮。');
  }
  await sleep(1000);
  clickOnce(okBtn);
  return true;
}

async function waitForSelectorOptional(selector, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (document.querySelector(selector)) {
      return true;
    }
    await sleep(150);
  }
  return false;
}

async function readCurrentHistorySuccessSignatures() {
  await clickButtonByText('查看导出历史', true);
  await waitForSelector('.ait-drawer.aep-drawer.ait-drawer-open', 10000);

  const drawer = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open');
  const rows = Array.from(drawer?.querySelectorAll('.ait-table-tbody tr.ait-table-row') || []);
  const set = new Set();

  rows.forEach((row) => {
    const rowText = textOf(row);
    if (!rowText.includes('成功')) {
      return;
    }
    set.add(buildHistoryRowSignature(row));
  });

  await closeHistoryDrawer();
  return set;
}

async function waitForTopDownloadableHistoryRow(baselineCounts, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const drawer = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open');
    if (!drawer) {
      await sleep(300);
      continue;
    }

    const rows = Array.from(drawer.querySelectorAll('.ait-table-tbody tr.ait-table-row'));
    if (rows.length === 0) {
      await sleep(800);
      continue;
    }

    const row = rows[0];
    const rowText = textOf(row);
    const signature = buildHistoryRowSignature(row);
    const currentCount = rows.reduce((sum, item) => {
      return sum + (buildHistoryRowSignature(item) === signature ? 1 : 0);
    }, 0);
    const baselineCount = baselineCounts instanceof Map ? (baselineCounts.get(signature) || 0) : 0;

    const isNewRow = currentCount > baselineCount;
    if (!isNewRow) {
      await sleep(800);
      continue;
    }

    if (!rowText.includes('成功')) {
      await sleep(800);
      continue;
    }

    const btn = row.querySelector('button');
    if (!btn) {
      await sleep(800);
      continue;
    }

    const btnText = normalizeButtonText(textOf(btn), true);
    const isDisabled = btn.hasAttribute('disabled') || String(btn.className || '').toLowerCase().includes('disabled');
    if (!btnText.includes('下载') || isDisabled) {
      await sleep(800);
      continue;
    }

    return row;

    await sleep(1000);
  }

  throw new Error('导出历史第一条在超时时间内未变为可下载状态。');
}

async function waitForLatestSuccessfulHistoryRows(baselineSet, expectedCount, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const drawer = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open');
    if (!drawer) {
      await sleep(300);
      continue;
    }

    const rows = Array.from(drawer.querySelectorAll('.ait-table-tbody tr.ait-table-row'));
    const matched = [];

    for (const row of rows) {
      const rowText = textOf(row);
      if (!rowText.includes('成功')) {
        continue;
      }

      const btn = row.querySelector('button');
      if (!btn) {
        continue;
      }

      const signature = buildHistoryRowSignature(row);
      if (baselineSet && baselineSet.has(signature)) {
        continue;
      }

      const btnText = normalizeButtonText(textOf(btn), true);
      const isDisabled = btn.hasAttribute('disabled') || String(btn.className || '').toLowerCase().includes('disabled');
      if (!btnText.includes('下载') || isDisabled) {
        continue;
      }

      matched.push(row);
      if (matched.length >= expectedCount) {
        return matched;
      }
    }

    await sleep(1000);
  }

  throw new Error('在导出历史中未等到足够的可下载成功记录。');
}

function buildHistoryRowSignature(row) {
  const cells = Array.from(row.querySelectorAll('td'));
  const fileName = textOf(cells[0]);
  const exportTime = textOf(cells[1]);
  return `${fileName}|${exportTime}`;
}

async function closeHistoryDrawer() {
  const closeBtn = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open .ait-drawer-close');
  if (closeBtn) {
    dispatchClick(closeBtn);
  }

  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    const drawer = document.querySelector('.ait-drawer.aep-drawer.ait-drawer-open');
    if (!drawer) {
      return;
    }
    await sleep(120);
  }
}

async function runExport(payload) {
  const month = String(payload.month || '').trim();
  const storeTag = String(payload.storeTag || '').trim();
  const { startText: plannedStartText, endText: plannedEndText, monthCompact } = buildMonthRange(month);

  await waitForSelector('.order-export-filters', 20000);

  await ensurePaymentTimeSelected();
  const appliedRange = await setDateRange(plannedStartText, plannedEndText);
  await chooseSelectOption('.order-export-reason-select', '对账');
  const baselineSet = readCurrentOrderHistorySignatures();

  await clickButtonByText('导出订单', false, true);

  await chrome.runtime.sendMessage({
    type: 'PREPARE_DOWNLOAD_RENAME',
    payload: {
      storeTag: storeTag || 'store',
      monthTag: month,
      month: monthCompact
    }
  });

  await waitForDownloadableHistoryRow(baselineSet);

  return {
    rangeText: `${appliedRange.startText} - ${appliedRange.endText}`
  };
}

function buildMonthRange(month) {
  const match = month.match(/^(\d{4})-(\d{2})$/);
  if (!match) {
    throw new Error('月份格式必须是 YYYY-MM。');
  }

  const year = Number(match[1]);
  const mon = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(mon) || mon < 1 || mon > 12) {
    throw new Error('月份不合法。');
  }

  const endDay = new Date(year, mon, 0).getDate();
  const mm = String(mon).padStart(2, '0');
  return {
    startText: `${year}-${mm}-01 00:00:00`,
    endText: `${year}-${mm}-${String(endDay).padStart(2, '0')} 23:59:59`,
    monthCompact: `${year}${mm}`
  };
}

async function waitForDownloadableHistoryRow(baselineSet) {
  const deadline = Date.now() + HISTORY_TIMEOUT_MS;
  let targetKey = '';

  while (Date.now() < deadline) {
    const rows = Array.from(document.querySelectorAll('.next-table-body tr'));

    if (!targetKey) {
      const freshRow = rows.find((row) => {
        const key = buildOrderHistoryStableKey(row);
        return Boolean(key) && !(baselineSet && baselineSet.has(key));
      });
      if (freshRow) {
        targetKey = buildOrderHistoryStableKey(freshRow);
      }
    }

    if (targetKey) {
      const targetRow = rows.find((row) => buildOrderHistoryStableKey(row) === targetKey);
      if (targetRow) {
        const status = readOrderHistoryStatus(targetRow);
        const action = findOrderHistoryDownloadAction(targetRow);

        const completed = status.includes('完成')
        if (completed && action) {
          await triggerDownloadAction(action);
          return;
        }
      }
    }

    const refresh = document.querySelector('.order-export-refresh');
    if (refresh) {
      refresh.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    }

    await sleep(STATUS_WAIT_MS);
  }

  throw new Error('导出历史在超时时间内未出现可下载记录。');
}

async function triggerDownloadAction(action) {
  if (!action) {
    return;
  }

  const downloadLink = readActionDownloadUrl(action);
  if (downloadLink) {
    const directResult = await requestBackgroundDownloadByUrl(downloadLink);
    if (directResult) {
      return;
    }
  }

  // Prefer full event chain to work with React/Next event delegation.
  dispatchClick(action);

  // Some pages wrap actionable link in parent node; click parent as fallback.
  const parentAction = action.closest('a,button,[role="button"]');
  if (parentAction && parentAction !== action) {
    dispatchClick(parentAction);
  }
}

function readActionDownloadUrl(action) {
  const anchor = action.closest('a[href]') || action.querySelector?.('a[href]') || null;
  const href = String(anchor?.getAttribute?.('href') || anchor?.href || '').trim();
  if (!href) {
    return '';
  }
  if (!/^https?:\/\//i.test(href)) {
    return '';
  }
  return href;
}

async function requestBackgroundDownloadByUrl(url) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'DIRECT_DOWNLOAD_URL',
      payload: { url }
    });
    return Boolean(response?.ok);
  } catch {
    return false;
  }
}

function readCurrentOrderHistorySignatures() {
  const rows = Array.from(document.querySelectorAll('.next-table-body tr'));
  return new Set(rows.map((row) => buildOrderHistoryStableKey(row)).filter((x) => x));
}

function buildOrderHistoryStableKey(row) {
  const wrappers = Array.from(row.querySelectorAll('td .next-table-cell-wrapper'));
  if (wrappers.length > 0) {
    // Use columns before status/action to keep identity stable while status changes from "处理中" to "完成".
    return wrappers
      .slice(0, Math.min(6, wrappers.length))
      .map((el) => textOf(el))
      .join('|');
  }
  return textOf(row).replace(/\s+/g, ' ');
}

function readOrderHistoryStatus(row) {
  const wrappers = Array.from(row.querySelectorAll('td .next-table-cell-wrapper'));
  if (wrappers.length >= 7) {
    return textOf(wrappers[6]);
  }
  return textOf(row);
}

function findOrderHistoryDownloadAction(row) {
  const direct = row.querySelector('a[href*="download"], a[href*="Download"], button[title*="下载"]');
  if (direct) {
    const disabledByStyle = String(direct.getAttribute('style') || '').toLowerCase().includes('not-allowed');
    const disabledByClass = String(direct.getAttribute('class') || '').toLowerCase().includes('disabled');
    if (!(disabledByStyle || disabledByClass || direct.hasAttribute('disabled'))) {
      return direct;
    }
  }

  const candidates = Array.from(row.querySelectorAll('a,button,span,div'));
  for (const el of candidates) {
    const txt = textOf(el);
    if (!txt.includes('下载')) {
      continue;
    }
    const disabledByStyle = String(el.getAttribute('style') || '').toLowerCase().includes('not-allowed');
    const disabledByClass = String(el.getAttribute('class') || '').toLowerCase().includes('disabled');
    if (disabledByStyle || disabledByClass || el.hasAttribute('disabled')) {
      continue;
    }
    return el.closest('a,button') || el;
  }
  return null;
}

async function chooseSelectOption(triggerSelector, optionText) {
  const trigger = document.querySelector(triggerSelector);
  if (!trigger) {
    throw new Error(`未找到下拉框：${triggerSelector}`);
  }

  dispatchClick(trigger);
  await sleep(250);

  const clicked = clickOptionInOverlay(optionText, triggerSelector);
  if (!clicked) {
    throw new Error(`未找到下拉项：${optionText}`);
  }

  await sleep(250);
}

function clickOptionInOverlay(text, triggerSelector = '') {
  if (triggerSelector.includes('order-export-time-select')) {
    const openedOverlay = document.querySelector('.next-overlay-wrapper.opened');
    if (openedOverlay) {
      const targetLi = openedOverlay.querySelector(`li[title="${text}"]`);
      if (targetLi) {
        dispatchClick(targetLi);
        return true;
      }

      const targetText = Array.from(openedOverlay.querySelectorAll('.next-menu-item-text'))
        .find((el) => textOf(el) === text);
      if (targetText) {
        dispatchClick(targetText.closest('li') || targetText);
        return true;
      }
    }
  }

  const roots = Array.from(document.querySelectorAll('.next-overlay-wrapper.opened, .next-overlay-wrapper, .next-overlay-inner, .next-select-menu, body'));
  for (const root of roots) {
    const candidates = Array.from(root.querySelectorAll('li, div, span, em, p, a'));
    const exact = candidates.find((el) => textOf(el) === text);
    if (exact) {
      dispatchClick(exact);
      return true;
    }

    const fuzzy = candidates.find((el) => textOf(el).includes(text));
    if (fuzzy) {
      dispatchClick(fuzzy);
      return true;
    }
  }

  return false;
}

async function setDateRange(startText, endText) {
  const plannedStartDate = startText.slice(0, 10);
  const plannedEndDate = endText.slice(0, 10);

  const [startInput, endInput] = getRangeInputs();
  if (!startInput || !endInput) {
    throw new Error('未找到日期范围输入框。');
  }

  const appliedStartDate = await pickRangeSide(startInput, plannedStartDate, '00', '00', '00', false);
  const appliedEndDate = await pickRangeSide(endInput, plannedEndDate, '23', '59', '59', true);

  await waitUntil(() => {
    const [leftWrap, rightWrap] = getRangeInputs();
    const leftInput = leftWrap?.querySelector('input');
    const rightInput = rightWrap?.querySelector('input');
    const leftValue = String(leftInput?.value || '');
    const rightValue = String(rightInput?.value || '');
    return leftValue.includes(appliedStartDate) && rightValue.includes(appliedEndDate);
  }, 8000, '日期范围写入失败');

  return {
    startText: `${appliedStartDate} 00:00:00`,
    endText: `${appliedEndDate} 23:59:59`
  };
}

function getRangeInputs() {
  return Array.from(document.querySelectorAll('.order-export-filter-time .ait-picker-range .ait-picker-input'));
}

async function pickRangeSide(inputWrapEl, dateText, hh, mm, ss, allowEndFallback) {
  const fullDateTime = `${dateText} ${hh}:${mm}:${ss}`;
  const inputEl = inputWrapEl.querySelector('input');

  dispatchClick(inputWrapEl);
  await waitForSelector('.ait-picker-dropdown-range', 8000);

  // Prefer direct text assignment to avoid unstable month-jump behavior in range picker panels.
  if (inputEl) {
    setInputDateTimeValue(inputEl, fullDateTime);
    await clickPickerConfirm(true);
    await sleep(120);

    const typedValue = String(inputEl.value || '');
    if (typedValue.includes(dateText)) {
      return dateText;
    }
  }

  await ensurePickerAtMonth(dateText);

  let appliedDate = dateText;
  const clicked = clickDateCellIfVisible(dateText);
  if (!clicked) {
    if (!allowEndFallback) {
      throw new Error(`日期不可选：${dateText}`);
    }

    const fallbackDate = findLatestSelectableDateInMonth(dateText.slice(0, 7));
    if (!fallbackDate || !clickDateCellIfVisible(fallbackDate)) {
      throw new Error(`结束日期不可选：${dateText}`);
    }
    appliedDate = fallbackDate;
  }

  await setPickerTime(hh, mm, ss);
  await clickPickerConfirm(false);
  return appliedDate;
}

async function ensurePickerAtMonth(dateText) {
  const [yText, mText] = dateText.split('-');
  const targetYear = Number(yText);
  const targetMonth = Number(mText);

  for (let i = 0; i < 30; i += 1) {
    const panelInfo = getPrimaryPickerPanelInfo();
    if (!panelInfo) {
      await sleep(180);
      continue;
    }

    const { panelYear, panelMonth, panelRoot } = panelInfo;
    if (panelYear === targetYear && panelMonth === targetMonth) {
      return;
    }

    const goPrev = panelYear > targetYear || (panelYear === targetYear && panelMonth > targetMonth);
    const btn = panelRoot.querySelector(goPrev ? '.ait-picker-header-prev-btn' : '.ait-picker-header-next-btn');
    if (!btn) {
      break;
    }

    dispatchClick(btn);
    await sleep(160);
  }

  throw new Error(`无法切换到目标月份：${dateText}`);
}

function getPrimaryPickerPanelInfo() {
  const panels = Array.from(document.querySelectorAll('.ait-picker-dropdown-range .ait-picker-panel'));
  const visiblePanel = panels.find((panel) => {
    const rect = panel.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }) || panels[0];

  if (!visiblePanel) {
    return null;
  }

  const yearText = textOf(visiblePanel.querySelector('.ait-picker-year-btn'));
  const monthText = textOf(visiblePanel.querySelector('.ait-picker-month-btn'));
  const yearMatch = yearText.match(/(\d{4})/);
  const monthMatch = monthText.match(/(\d{1,2})/);
  if (!yearMatch || !monthMatch) {
    return null;
  }

  return {
    panelRoot: visiblePanel,
    panelYear: Number(yearMatch[1]),
    panelMonth: Number(monthMatch[1])
  };
}

function clickDateCellIfVisible(dateText, doClick = true) {
  const candidates = Array.from(document.querySelectorAll(`.ait-picker-dropdown-range td[title="${dateText}"]`));
  const cell = candidates.find((el) => !el.classList.contains('ait-picker-cell-disabled'));
  if (!cell) {
    return false;
  }

  if (!doClick) {
    return true;
  }

  const clickable = cell.querySelector('.ait-picker-cell-inner') || cell;
  dispatchClick(clickable);
  return true;
}

function findLatestSelectableDateInMonth(monthText) {
  const cells = Array.from(document.querySelectorAll('.ait-picker-dropdown-range td[title]'));
  const dates = cells
    .filter((cell) => !cell.classList.contains('ait-picker-cell-disabled'))
    .map((cell) => String(cell.getAttribute('title') || '').trim())
    .filter((title) => /^\d{4}-\d{2}-\d{2}$/.test(title) && title.startsWith(`${monthText}-`))
    .sort();

  if (dates.length === 0) {
    return '';
  }
  return dates[dates.length - 1];
}

async function setPickerTime(hh, mm, ss) {
  const columns = Array.from(document.querySelectorAll('.ait-picker-dropdown-range .ait-picker-time-panel-column'));
  if (columns.length < 3) {
    return;
  }

  clickTimeColumnValue(columns[0], hh);
  clickTimeColumnValue(columns[1], mm);
  clickTimeColumnValue(columns[2], ss);
  await sleep(120);
}

function clickTimeColumnValue(columnEl, valueText) {
  const items = Array.from(columnEl.querySelectorAll('.ait-picker-time-panel-cell'));
  const target = items.find((item) => textOf(item.querySelector('.ait-picker-time-panel-cell-inner')) === valueText);
  if (target) {
    dispatchClick(target);
  }
}

async function clickPickerConfirm(allowDisabled) {
  const okBtn = document.querySelector('.ait-picker-dropdown-range .ait-picker-ok button');
  if (!okBtn) {
    throw new Error('未找到时间选择器确认按钮。');
  }

  if (!allowDisabled) {
    await waitUntil(() => !okBtn.disabled, 4000, '确认按钮未激活');
  }
  dispatchClick(okBtn);
  await sleep(220);
}

function setInputDateTimeValue(input, value) {
  input.removeAttribute('readonly');
  input.focus();

  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (descriptor && typeof descriptor.set === 'function') {
    descriptor.set.call(input, value);
  } else {
    input.value = value;
  }

  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
  input.blur();
}

async function ensurePaymentTimeSelected() {
  const labelText = readTimeBasisText();
  if (labelText.includes('付款时间')) {
    return;
  }

  const trigger = document.querySelector('.order-export-time-select')
    || document.querySelector('.order-export-filter-time .next-select');
  if (!trigger) {
    throw new Error('未找到时间口径下拉框。');
  }

  dispatchClick(trigger);
  await sleep(220);

  const clicked = clickOptionInOverlay('付款时间', 'order-export-time-select');
  if (!clicked) {
    throw new Error('未找到“付款时间”选项。');
  }

  await waitUntil(() => {
    const text = readTimeBasisText();
    return text.includes('付款时间');
  }, 5000, '未成功切换到付款时间');
}

function readTimeBasisText() {
  const em = document.querySelector('.order-export-time-select .next-select-values em');
  const emText = textOf(em);
  if (emText) {
    return emText;
  }

  const input = document.querySelector('.order-export-time-select input[role="combobox"]');
  const ariaText = String(input?.getAttribute('aria-valuetext') || '').trim();
  if (ariaText) {
    return ariaText;
  }

  return textOf(document.querySelector('.order-export-time-select .next-input-text-field'));
}

async function clickButtonByText(buttonText, normalizeSpace, singleClick = false) {
  const deadline = Date.now() + 10000;
  const expected = normalizeButtonText(buttonText, normalizeSpace);

  while (Date.now() < deadline) {
    const buttons = Array.from(document.querySelectorAll('button'));
    const target = buttons.find((btn) => {
      const current = normalizeButtonText(textOf(btn), normalizeSpace);
      return current.includes(expected);
    });
    if (target) {
      if (singleClick) {
        clickOnce(target);
      } else {
        dispatchClick(target);
      }
      return;
    }
    await sleep(300);
  }

  throw new Error(`未找到按钮：${buttonText}`);
}

function normalizeButtonText(text, normalizeSpace) {
  const base = String(text || '').trim();
  if (!normalizeSpace) {
    return base;
  }
  return base.replace(/\s+/g, '');
}

async function waitForSelector(selector, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (document.querySelector(selector)) {
      return;
    }
    await sleep(150);
  }
  throw new Error(`等待元素超时：${selector}`);
}

function textOf(el) {
  return String(el?.textContent || '').trim();
}

async function waitUntil(checker, timeoutMs, timeoutMessage) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (checker()) {
      return;
    }
    await sleep(120);
  }
  throw new Error(timeoutMessage);
}

function dispatchClick(el) {
  if (!el) return;
  if (typeof el.click === 'function') {
    el.click();
  }
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

function clickOnce(el) {
  if (!el) return;
  if (typeof el.click === 'function') {
    el.click();
    return;
  }
  el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
