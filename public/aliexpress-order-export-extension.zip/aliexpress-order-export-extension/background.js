const pendingRenameQueue = [];
const ORDER_EXPORT_URL = 'https://csp.aliexpress.com/m_apps/order-manage/orderExport';
const FUND_DETAIL_BASE = 'https://csp.aliexpress.com/m_apps/fund/overview?channelId=1221007#/home/AEG/order/details';
const FUND_DETAIL_BASE_RU = 'https://csp.aliexpress.com/m_apps/fund/overview?channelId=1221007#/home/AER/order/details';
const FUND_INCOME_EXPENSE_BASE = 'https://csp.aliexpress.com/m_apps/fund/overview?channelId=2223756#/home/AEG/incomeAndExpense/details';
const FUND_REFUND_BASE = 'https://csp.aliexpress.com/m_apps/fund/overview?channelId=1221007#/home/AEG/order/refundDetails';
const FUND_REFUND_BASE_RU = 'https://csp.aliexpress.com/m_apps/fund/overview?channelId=1221007#/home/AER/order/refundDetails';
const JZG_BILL_BASE = 'https://b.cainiao.com/cf_seller/merchant-counter-bill-manage';
const JZG_BILL_BASE_RU = 'https://b.cainiao.com/cf_seller/merchant-counter-bill-manage';
const FUND_EXPORT_STEP_GAP_MS = 1500;
const CHINA_TZ_OFFSET_MS = 8 * 60 * 60 * 1000;
const DEBUG_PREFIX = '[ae-export-debug]';
const KEEP_EXPORT_TABS_OPEN = true;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'START_EXPORT_WORKFLOW') {
    void startExportWorkflow(message.payload || {})
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'DIRECT_DOWNLOAD_URL') {
    const url = String(message?.payload?.url || '').trim();
    if (!url) {
      sendResponse({ ok: false, error: '下载链接为空。' });
      return;
    }

    chrome.downloads.download(
      {
        url,
        conflictAction: 'uniquify'
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message || '下载失败' });
          return;
        }
        sendResponse({ ok: true, downloadId: Number(downloadId || 0) });
      }
    );
    return true;
  }

  if (message?.type !== 'PREPARE_DOWNLOAD_RENAME') {
    return;
  }

  const ok = prepareDownloadRename(message.payload || {}, sender?.tab?.id || null);
  if (!ok) {
    sendResponse({ ok: false, error: 'Invalid period tag for rename.' });
    return;
  }

  sendResponse({ ok: true });
});

async function startExportWorkflow(payload) {
  // Prevent stale rename tasks from older runs from contaminating current filenames.
  pendingRenameQueue.length = 0;

  const exportType = String(payload.exportType || 'order_details').trim();

  if (exportType === 'order_export') {
    return startOrderExportWorkflow(payload);
  }

  if (exportType === 'jzg_bill') {
    return startJzgBillWorkflow(payload);
  }

  if (exportType === 'refund_details') {
    return startFundBatchWorkflow(payload, {
      nonRuBase: FUND_REFUND_BASE,
      ruBase: FUND_REFUND_BASE_RU,
      submitMessageType: 'START_FUND_REFUND_EXPORT',
      fileType: '退放款明细',
      dateType: 'dateRange',
      extraParams: {
        businessType: 'null'
      }
    });
  }

  return startFundBatchWorkflow(payload, {
    submitMessageType: 'START_FUND_DETAILS_EXPORT',
    fileType: '订单明细',
    dateType: 'monthRange',
    planBuilder: buildOrderDetailPlans
  });
}

async function startOrderExportWorkflow(payload) {
  const tab = await chrome.tabs.create({
    url: ORDER_EXPORT_URL,
    active: true
  });

  if (!tab?.id) {
    throw new Error('无法创建导出页面标签页。');
  }

  await waitForTabComplete(tab.id, 60000);
  await sleep(800);

  const response = await sendMessageWithRetry(
    tab.id,
    {
      type: 'START_ORDER_LIST_EXPORT',
      payload
    },
    12,
    800
  );

  if (!response?.ok) {
    throw new Error(response?.error || '页面导出执行失败');
  }

  return {
    total: 1,
    details: [{ label: '订单导出', rangeText: response.rangeText || '' }],
    rangeText: response.rangeText || ''
  };
}

async function startFundBatchWorkflow(payload, options) {
  const month = String(payload.month || '').trim();
  const storeTag = String(payload.storeTag || '').trim();
  const includeNonRu = payload.includeNonRu !== false;
  const includeRu = payload.includeRu !== false;

  if (!includeNonRu && !includeRu) {
    throw new Error('请至少选择一个国家（俄罗斯或非俄罗斯）。');
  }

  const ranges = buildRangesFromMonth(month);
  console.log(`${DEBUG_PREFIX} fund ranges`, {
    exportType: options.submitMessageType,
    month,
    ranges: ranges.map((item) => ({
      start: formatDateFromMs(item.startMs),
      end: formatDateFromMs(item.endMs),
      text: item.text
    }))
  });
  const rawPlans = typeof options.planBuilder === 'function'
    ? options.planBuilder(ranges, {
      includeNonRu,
      includeRu
    })
    : buildExportPlans(
      ranges,
      options.nonRuBase,
      options.ruBase,
      options.dateType || 'monthRange',
      options.extraParams || {},
      {
        includeNonRu,
        includeRu
      }
    );
  const plans = dedupePlans(rawPlans);
  console.log(`${DEBUG_PREFIX} fund plans`, plans.map((plan) => ({
    label: plan.label,
    periodTag: plan.periodTag,
    regionTag: plan.regionTag,
    rangeText: plan.rangeText
  })));

  if (plans.length === 0) {
    return {
      total: 0,
      skipped: 0,
      details: [],
      rangeText: ''
    };
  }

  const results = [];

  for (let i = 0; i < plans.length; i += 1) {
    const plan = plans[i];
    const tab = await chrome.tabs.create({
      url: plan.url,
      active: i === 0
    });

    if (!tab?.id) {
      throw new Error(`无法创建导出页面标签页：${plan.label}`);
    }

    let response;
    try {
      await waitForTabComplete(tab.id, 60000);
      await sleep(1200);

      response = await sendMessageWithRetry(
        tab.id,
        {
          type: options.submitMessageType,
          payload: {
            label: plan.label,
            rangeText: plan.rangeText,
            storeTag,
            monthTag: month,
            periodTag: plan.periodTag,
            regionTag: plan.regionTag,
            fileType: plan.fileType || options.fileType || '订单明细'
          }
        },
        15,
        800
      );

      if (!response?.ok) {
        throw new Error(response?.error || `页面导出执行失败：${plan.label}`);
      }
    } finally {
      if (!KEEP_EXPORT_TABS_OPEN && tab.id) {
        chrome.tabs.remove(tab.id, () => {});
      }
    }

    results.push({
      label: plan.label,
      rangeText: plan.rangeText
    });

    await sleep(FUND_EXPORT_STEP_GAP_MS);
  }

  return {
    total: results.length,
    skipped: 0,
    details: results,
    rangeText: results.map((item) => `${item.label} ${item.rangeText}`).join('；')
  };
}

async function startJzgBillWorkflow(payload) {
  const month = String(payload.month || '').trim();
  const storeTag = String(payload.storeTag || '').trim();
  const ranges = [buildJzgRangeFromMonth(month)];
  const rawPlans = buildExportPlans(
    ranges,
    JZG_BILL_BASE,
    JZG_BILL_BASE_RU,
    'dateRange',
    {},
    {
      includeNonRu: true,
      includeRu: false
    }
  );
  const plans = dedupePlans(rawPlans);
  console.log(`${DEBUG_PREFIX} jzg plans`, plans.map((plan) => ({
    label: plan.label,
    periodTag: plan.periodTag,
    regionTag: plan.regionTag,
    rangeText: plan.rangeText
  })));

  const results = [];
  let skipped = 0;
  const skippedLabels = [];

  for (let i = 0; i < plans.length; i += 1) {
    const plan = plans[i];
    const tab = await chrome.tabs.create({
      url: plan.url,
      active: false
    });

    if (!tab?.id) {
      throw new Error(`无法创建金掌柜页面标签页：${plan.label}`);
    }

    await waitForTabComplete(tab.id, 60000);
    await sleep(1000);

    prepareDownloadRename(
      {
        storeTag,
        monthTag: month,
        periodTag: plan.periodTag,
        regionTag: plan.regionTag,
        fileType: '金掌柜账单'
      },
      tab.id
    );

    const response = await sendMessageWithRetry(
      tab.id,
      {
        type: 'START_JZG_BILL_EXPORT',
        payload: {
          label: plan.label,
          rangeText: plan.rangeText,
          storeTag,
          periodTag: plan.periodTag,
          regionTag: plan.regionTag,
          startDate: plan.startDate || formatDateFromMs(plan.startMs),
          endDate: plan.endDate || formatDateFromMs(plan.endMs)
        }
      },
      15,
      800
    );
    console.log(`${DEBUG_PREFIX} jzg payload sent`, {
      label: plan.label,
      tabId: tab.id,
      startDate: plan.startDate || formatDateFromMs(plan.startMs),
      endDate: plan.endDate || formatDateFromMs(plan.endMs),
      periodTag: plan.periodTag,
      rangeText: plan.rangeText
    });

    if (!response?.ok) {
      throw new Error(response?.error || `金掌柜执行失败：${plan.label}`);
    }

    if (response?.skipped) {
      skipped += 1;
      skippedLabels.push(plan.label);
    }

    results.push({
      label: plan.label,
      rangeText: plan.rangeText
    });
  }

  return {
    total: results.length,
    skipped,
    skippedLabels,
    details: results,
    rangeText: results.map((item) => `${item.label} ${item.rangeText}`).join('；')
  };
}

function buildJzgRangeFromMonth(month) {
  const match = month.match(/^(\d{4})-(\d{2})$/);
  if (!match) {
    throw new Error('月份格式必须是 YYYY-MM。');
  }

  const year = Number(match[1]);
  const mon = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(mon) || mon < 1 || mon > 12) {
    throw new Error('月份不合法。');
  }

  const startDate = `${year}-${String(mon).padStart(2, '0')}-01`;
  const todayDate = getBusinessYesterdayDateText();

  const cappedMonth = mon + 2;
  const cappedMonthYear = year + Math.floor((cappedMonth - 1) / 12);
  const cappedMonthNormalized = ((cappedMonth - 1) % 12) + 1;
  const cappedEndDay = getMonthLastDay(cappedMonthYear, cappedMonthNormalized);
  const cappedEndDate = `${cappedMonthYear}-${String(cappedMonthNormalized).padStart(2, '0')}-${String(cappedEndDay).padStart(2, '0')}`;
  const endDate = cappedEndDate > todayDate ? todayDate : cappedEndDate;

  const startMs = toChinaEpochMsFromDate(startDate, false);
  const endMs = toChinaEpochMsFromDate(endDate, true);
  console.log(`${DEBUG_PREFIX} jzg range computed`, {
    selectedMonth: month,
    startDate,
    cappedEndDate,
    todayDate,
    endDate
  });

  return {
    startMs,
    endMs,
    startDate,
    endDate,
    text: `${startDate} ~ ${endDate}`
  };
}

function getBusinessYesterdayDateText() {
  // JZG cap rule: use previous business day (UTC calendar day - 1).
  const now = new Date();
  const yesterdayUtcMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()) - 24 * 60 * 60 * 1000;
  const y = new Date(yesterdayUtcMs).getUTCFullYear();
  const m = String(new Date(yesterdayUtcMs).getUTCMonth() + 1).padStart(2, '0');
  const d = String(new Date(yesterdayUtcMs).getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function dedupePlans(plans) {
  const seen = new Set();
  const output = [];

  plans.forEach((plan) => {
    const key = `${plan.url}|${plan.periodTag}`;
    if (seen.has(key)) {
      return;
    }
    seen.add(key);
    output.push(plan);
  });

  return output;
}

function buildExportPlans(ranges, nonRuBase, ruBase, dateType, extraParams, filters) {
  const includeNonRu = filters?.includeNonRu !== false;
  const includeRu = filters?.includeRu !== false;
  const plans = [];
  ranges.forEach((range, index) => {
    const partNo = index + 1;
    const periodTag = buildPeriodTag(range.startMs, range.endMs);
    if (includeNonRu) {
      plans.push({
        label: `非俄罗斯-第${partNo}段`,
        regionTag: '非俄罗斯',
        periodTag,
        startMs: range.startMs,
        endMs: range.endMs,
        startDate: range.startDate || '',
        endDate: range.endDate || '',
        rangeText: range.text,
        url: buildFundDetailUrl(nonRuBase, range, dateType, extraParams)
      });
    }
    if (includeRu) {
      plans.push({
        label: `俄罗斯-第${partNo}段`,
        regionTag: '俄罗斯',
        periodTag,
        startMs: range.startMs,
        endMs: range.endMs,
        startDate: range.startDate || '',
        endDate: range.endDate || '',
        rangeText: range.text,
        url: buildFundDetailUrl(ruBase, range, dateType, extraParams)
      });
    }
  });
  return plans;
}

function buildOrderDetailPlans(ranges, filters) {
  const includeNonRu = filters?.includeNonRu !== false;
  const includeRu = filters?.includeRu !== false;
  const plans = [];

  ranges.forEach((range, index) => {
    const partNo = index + 1;
    const periodTag = buildPeriodTag(range.startMs, range.endMs);

    if (includeNonRu) {
      plans.push({
        label: `非俄罗斯-第${partNo}段`,
        regionTag: '非俄罗斯',
        periodTag,
        startMs: range.startMs,
        endMs: range.endMs,
        rangeText: range.text,
        fileType: '订单收支明细',
        url: buildFundDetailUrl(FUND_INCOME_EXPENSE_BASE, range, 'monthRange', {
          timeType: '结算时间'
        })
      });
    }

    if (includeRu) {
      plans.push({
        label: `俄罗斯-第${partNo}段`,
        regionTag: '俄罗斯',
        periodTag,
        startMs: range.startMs,
        endMs: range.endMs,
        rangeText: range.text,
        fileType: '订单明细',
        url: buildFundDetailUrl(FUND_DETAIL_BASE_RU, range, 'monthRange', {
          timeType: 'PAY_TIME'
        })
      });
    }
  });

  return plans;
}

function formatDateFromMs(ms) {
  return formatBusinessDate(ms);
}

function buildPeriodTag(startMs, endMs) {
  const startMonth = toBusinessMonthString(startMs);
  const endMonth = toBusinessMonthString(endMs);
  return startMonth === endMonth ? startMonth : `${startMonth}-${endMonth}`;
}

function toBusinessDate(ms) {
  // Internal epoch values are encoded with +8h shift for backend query semantics.
  // Subtract the shift before extracting calendar parts so month-end doesn't roll over.
  return new Date(ms - CHINA_TZ_OFFSET_MS);
}

function formatBusinessDate(ms) {
  const date = toBusinessDate(ms);
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function toBusinessMonthString(ms) {
  const date = toBusinessDate(ms);
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  return `${y}${m}`;
}

function toMonthString(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}${m}`;
}

function buildFundDetailUrl(base, range, dateType, extraParams) {
  const hashPos = base.indexOf('#');
  const beforeHash = hashPos >= 0 ? base.slice(0, hashPos) : base;
  const hashPart = hashPos >= 0 ? base.slice(hashPos + 1) : '';

  const datePayload = {
    startTime: range.startMs,
    endTime: range.endMs,
    dateType: dateType || 'monthRange'
  };

  const params = new URLSearchParams();
  params.set('pageSize', '10');
  params.set('current', '1');
  params.set('timeType', 'PAY_TIME');
  params.set('date', JSON.stringify(datePayload));
  params.set('currency', 'CNY');

  Object.entries(extraParams || {}).forEach(([key, value]) => {
    params.set(key, String(value));
  });

  return `${beforeHash}#${hashPart}?${params.toString()}`;
}

function buildRangesFromMonth(month) {
  const match = month.match(/^(\d{4})-(\d{2})$/);
  if (!match) {
    throw new Error('月份格式必须是 YYYY-MM。');
  }

  const year = Number(match[1]);
  const mon = Number(match[2]);
  if (!Number.isFinite(year) || !Number.isFinite(mon) || mon < 1 || mon > 12) {
    throw new Error('月份不合法。');
  }

  const firstStartMs = toChinaEpochMs(year, mon, 1, 0, 0, 0, 0);
  const chinaToday = getChinaTodayParts();
  const firstEndMs = toChinaEpochMs(chinaToday.year, chinaToday.month, chinaToday.day, 23, 59, 59, 999);

  const currentMonthIndex = chinaToday.year * 12 + (chinaToday.month - 1);
  const selectedMonthIndex = year * 12 + (mon - 1);
  const monthGap = currentMonthIndex - selectedMonthIndex;

  // Split only when covered months exceed 3.
  // monthGap + 1 = covered month count.
  if (monthGap <= 2) {
    return [
      {
        startMs: firstStartMs,
        endMs: firstEndMs,
        text: `${formatDateFromMs(firstStartMs)} ~ ${formatDateFromMs(firstEndMs)}`
      }
    ];
  }

  const prevMonth = chinaToday.month - 1;
  const prevMonthYear = prevMonth >= 1 ? chinaToday.year : chinaToday.year - 1;
  const prevMonthNormalized = prevMonth >= 1 ? prevMonth : 12;
  const prevMonthEndDay = getMonthLastDay(prevMonthYear, prevMonthNormalized);
  const splitEndMs = toChinaEpochMs(prevMonthYear, prevMonthNormalized, prevMonthEndDay, 23, 59, 59, 999);
  const secondStartMs = toChinaEpochMs(chinaToday.year, chinaToday.month, 1, 0, 0, 0, 0);

  return [
    {
      startMs: firstStartMs,
      endMs: splitEndMs,
      text: `${formatDateFromMs(firstStartMs)} ~ ${formatDateFromMs(splitEndMs)}`
    },
    {
      startMs: secondStartMs,
      endMs: firstEndMs,
      text: `${formatDateFromMs(secondStartMs)} ~ ${formatDateFromMs(firstEndMs)}`
    }
  ];
}

function formatDate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function toChinaEpochMs(year, month, day, hour, minute, second, ms) {
  // Cross-border export window: backend expects UTC epoch with +8h shift.
  // Example: 2026-03-01 00:00:00 (business day) -> 1772352000000.
  return Date.UTC(year, month - 1, day, hour, minute, second, ms) + CHINA_TZ_OFFSET_MS;
}

function toChinaEpochMsFromDate(dateText, endOfDay) {
  const match = String(dateText || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) {
    throw new Error(`日期格式非法：${dateText}`);
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (endOfDay) {
    return toChinaEpochMs(year, month, day, 23, 59, 59, 999);
  }
  return toChinaEpochMs(year, month, day, 0, 0, 0, 0);
}

function getMonthLastDay(year, month) {
  const normalized = new Date(Date.UTC(year, month, 0));
  return normalized.getUTCDate();
}

function getChinaTodayParts() {
  const shifted = new Date(Date.now() + CHINA_TZ_OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate()
  };
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error('页面加载超时。'));
    }, timeoutMs);

    const cleanup = () => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === 'complete') {
        cleanup();
        resolve();
      }
    };

    const onRemoved = (removedTabId) => {
      if (removedTabId !== tabId) return;
      cleanup();
      reject(new Error('导出标签页被关闭。'));
    };

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

async function sendMessageWithRetry(tabId, payload, maxAttempts, gapMs) {
  for (let i = 0; i < maxAttempts; i += 1) {
    try {
      const response = await sendTabMessage(tabId, payload);
      return response;
    } catch (error) {
      if (i === maxAttempts - 1) {
        throw error;
      }
      await sleep(gapMs);
    }
  }

  throw new Error('Failed to send export command to page.');
}

function sendTabMessage(tabId, payload) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  try {
    const pendingRename = consumePendingRenameForDownload(item);
    if (!pendingRename) {
      console.log(`${DEBUG_PREFIX} rename skipped (no pending)`, {
        tabId: item?.tabId,
        filename: item?.filename,
        finalUrl: item?.finalUrl
      });
      suggest();
      return;
    }

    const ext = detectExt(item.filename || item.finalUrl || '') || '.xlsx';
    const segments = [pendingRename.storeTag, pendingRename.periodTag];
    if (pendingRename.regionTag) {
      segments.push(pendingRename.regionTag);
    }
    segments.push(pendingRename.fileType || '订单列表');
    const fileName = `${segments.join('_')}${ext}`;
    const folderName = `${pendingRename.monthTag || deriveMonthTagFromPeriod(pendingRename.periodTag)}_${pendingRename.storeTag}`;
    console.log(`${DEBUG_PREFIX} rename apply`, {
      tabId: item?.tabId,
      periodTag: pendingRename.periodTag,
      regionTag: pendingRename.regionTag,
      fileType: pendingRename.fileType,
      target: `aliexpress-exports/${folderName}/${fileName}`
    });

    suggest({
      filename: `aliexpress-exports/${folderName}/${fileName}`,
      conflictAction: 'uniquify'
    });
  } catch (error) {
    suggest();
  }
});

function detectExt(input) {
  const text = String(input || '');
  const match = text.match(/\.([a-zA-Z0-9]{2,8})(?:$|\?)/);
  if (!match) {
    return '';
  }
  return `.${match[1].toLowerCase()}`;
}

function sanitizeSegment(value, fallback) {
  const text = String(value || '')
    .trim()
    .replace(/[\\/:*?"<>|]/g, '-')
    .replace(/\s+/g, '');
  return text || fallback || 'store';
}

function sanitizeMonthTag(value) {
  const raw = String(value || '').trim();
  const ym = raw.match(/^(\d{4})-(\d{2})$/);
  if (ym) {
    return `${ym[1]}-${ym[2]}`;
  }

  const compact = raw.match(/^(\d{4})(\d{2})$/);
  if (compact) {
    return `${compact[1]}-${compact[2]}`;
  }

  return '';
}

function deriveMonthTagFromPeriod(periodTag) {
  const text = String(periodTag || '');
  const match = text.match(/(\d{4})(\d{2})/);
  if (!match) {
    return 'period';
  }
  return `${match[1]}-${match[2]}`;
}

function prepareDownloadRename(payload, fromTabId) {
  const sessionTag = sanitizeSegment(payload.sessionTag || '', '');
  const storeTag = sanitizeSegment(payload.storeTag || 'store');
  const periodTag = sanitizeSegment(payload.periodTag || payload.month || '', 'period');
  const monthTag = sanitizeMonthTag(payload.monthTag || payload.month || '') || deriveMonthTagFromPeriod(periodTag);
  const regionTag = sanitizeSegment(payload.regionTag || '', '');
  const fileType = sanitizeSegment(payload.fileType || '', '订单列表');

  if (!periodTag) {
    return false;
  }

  pendingRenameQueue.push({
    storeTag,
    sessionTag,
    monthTag,
    periodTag,
    regionTag,
    fileType,
    preparedAt: Date.now(),
    fromTabId: fromTabId || null
  });
  console.log(`${DEBUG_PREFIX} rename queued`, {
    fromTabId: fromTabId || null,
    periodTag,
    regionTag,
    fileType,
    monthTag,
    queueSize: pendingRenameQueue.length
  });

  return true;
}

function consumeNextPendingRename() {
  const now = Date.now();
  while (pendingRenameQueue.length > 0) {
    const next = pendingRenameQueue.shift();
    if (!next) {
      continue;
    }
    const expired = now - next.preparedAt > 10 * 60 * 1000;
    if (expired) {
      continue;
    }
    return next;
  }
  return null;
}

function consumePendingRenameForDownload(downloadItem) {
  cleanupExpiredPendingRenameQueue();

  const tabId = Number(downloadItem?.tabId ?? -1);
  if (Number.isInteger(tabId) && tabId >= 0) {
    const matchedIndex = pendingRenameQueue.findIndex((item) => Number(item?.fromTabId ?? -1) === tabId);
    if (matchedIndex >= 0) {
      const [matched] = pendingRenameQueue.splice(matchedIndex, 1);
      console.log(`${DEBUG_PREFIX} rename consume by tabId`, {
        tabId,
        periodTag: matched?.periodTag,
        queueSize: pendingRenameQueue.length
      });
      return matched || null;
    }

    // Some downloads lose tab affinity after cross-origin redirects.
    // Fallback to queue order so rename still applies for sequential exports.
    console.log(`${DEBUG_PREFIX} rename tabId miss, fallback FIFO`, {
      tabId,
      queueSize: pendingRenameQueue.length
    });
    return consumeNextPendingRename();
  }

  return consumeNextPendingRename();
}

function cleanupExpiredPendingRenameQueue() {
  const now = Date.now();
  for (let i = pendingRenameQueue.length - 1; i >= 0; i -= 1) {
    const item = pendingRenameQueue[i];
    if (!item) {
      pendingRenameQueue.splice(i, 1);
      continue;
    }
    const expired = now - Number(item.preparedAt || 0) > 10 * 60 * 1000;
    if (expired) {
      pendingRenameQueue.splice(i, 1);
    }
  }
}
