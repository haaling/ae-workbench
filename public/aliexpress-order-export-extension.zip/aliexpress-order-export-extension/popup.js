const monthInput = document.getElementById('month');
const storeTagInput = document.getElementById('storeTag');
const sessionSelect = document.getElementById('sessionSelect');
const newSessionTagInput = document.getElementById('newSessionTag');
const addSessionBtn = document.getElementById('addSessionBtn');
const includeNonRuInput = document.getElementById('includeNonRu');
const includeRuInput = document.getElementById('includeRu');
const runOrderBtn = document.getElementById('runOrderBtn');
const runOrderDetailsBtn = document.getElementById('runOrderDetailsBtn');
const runRefundDetailsBtn = document.getElementById('runRefundDetailsBtn');
const runJzgBtn = document.getElementById('runJzgBtn');
const statusEl = document.getElementById('status');

const STORAGE_KEY = 'order_export_popup_form_v1';

runOrderBtn.addEventListener('click', () => onRun('order_export'));
runOrderDetailsBtn.addEventListener('click', () => onRun('order_details'));
runRefundDetailsBtn.addEventListener('click', () => onRun('refund_details'));
runJzgBtn.addEventListener('click', () => onRun('jzg_bill'));
storeTagInput.addEventListener('input', persistForm);
monthInput.addEventListener('input', persistForm);
sessionSelect.addEventListener('change', persistForm);
includeNonRuInput.addEventListener('change', persistForm);
includeRuInput.addEventListener('change', persistForm);
newSessionTagInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    onAddSession();
  }
});
addSessionBtn.addEventListener('click', onAddSession);

void initForm();

async function initForm() {
  const now = new Date();
  const defaultMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  try {
    const data = await storageGet(STORAGE_KEY);
    monthInput.value = typeof data?.month === 'string' ? data.month : defaultMonth;
    storeTagInput.value = typeof data?.storeTag === 'string' ? data.storeTag : '';
    includeNonRuInput.checked = typeof data?.includeNonRu === 'boolean' ? data.includeNonRu : true;
    includeRuInput.checked = typeof data?.includeRu === 'boolean' ? data.includeRu : true;

    const savedSessionTag = typeof data?.sessionTag === 'string' ? data.sessionTag.trim() : '';
    const savedSessions = normalizeSessions(data?.sessions);
    if (savedSessionTag && !savedSessions.includes(savedSessionTag)) {
      savedSessions.unshift(savedSessionTag);
    }

    renderSessionOptions(savedSessions, savedSessionTag);
  } catch (error) {
    setStatus(`读取已保存参数失败：${error.message || String(error)}`, true);
    monthInput.value = defaultMonth;
    includeNonRuInput.checked = true;
    includeRuInput.checked = true;
    renderSessionOptions([], '');
  }
}

function persistForm() {
  const sessions = getSessionOptions();
  void storageSet(STORAGE_KEY, {
    month: monthInput.value.trim(),
    storeTag: storeTagInput.value.trim(),
    includeNonRu: Boolean(includeNonRuInput.checked),
    includeRu: Boolean(includeRuInput.checked),
    sessionTag: sessionSelect.value.trim(),
    sessions
  });
}

function onAddSession() {
  const value = newSessionTagInput.value.trim();
  if (!value) {
    setStatus('请输入要添加的会话名称。', true);
    return;
  }

  const sessions = getSessionOptions();
  if (!sessions.includes(value)) {
    sessions.unshift(value);
  }

  renderSessionOptions(sessions, value);
  newSessionTagInput.value = '';
  setStatus(`会话已添加：${value}`);
  persistForm();
}

async function onRun(exportType) {
  const month = monthInput.value.trim();
  const storeTag = storeTagInput.value.trim();
  const sessionTag = sessionSelect.value.trim();
  const includeNonRu = Boolean(includeNonRuInput.checked);
  const includeRu = Boolean(includeRuInput.checked);

  const actionName = getActionName(exportType);

  if (!/^\d{4}-\d{2}$/.test(month)) {
    setStatus('月份格式必须是 YYYY-MM，例如 2026-01。', true);
    return;
  }

  if ((exportType === 'order_details' || exportType === 'refund_details') && !includeNonRu && !includeRu) {
    setStatus('请至少勾选一个国家：俄罗斯或非俄罗斯。', true);
    return;
  }

  setActionsDisabled(true);
  setStatus(`正在执行${actionName}...`);

  try {
    const response = await runtimeSendMessage({
      type: 'START_EXPORT_WORKFLOW',
      payload: {
        month,
        storeTag,
        sessionTag,
        exportType,
        includeNonRu,
        includeRu
      }
    });

    if (!response?.ok) {
      throw new Error(response?.error || '导出执行失败');
    }

    const hint = response.rangeText ? `，范围：${response.rangeText}` : '';
    const total = Number(response?.total || 0);
    const skipped = Number(response?.skipped || 0);
    const skippedLabels = Array.isArray(response?.skippedLabels) ? response.skippedLabels : [];
    const totalText = total > 0 ? `共 ${total} 份` : '已提交';
    const skipText = skipped > 0 ? `，其中 ${skipped} 份无数据已跳过` : '';
    const skipDetail = skippedLabels.length > 0 ? `（${skippedLabels.join('、')}）` : '';

    if (skipped > 0 && skipped === total) {
      setStatus(`${actionName}${totalText}${hint}，查询结果为空，未下载文件${skipDetail}。`, true);
      return;
    }

    if (exportType === 'jzg_bill') {
      setStatus(`${actionName}${totalText}${hint}${skipText}${skipDetail}。已保留页面，请在页面点击“下载查询结果”手动下载。`, false, true);
      return;
    }

    setStatus(`${actionName}${totalText}${hint}${skipText}${skipDetail}。文件已自动下载并重命名。`, false, true);
  } catch (error) {
    setStatus(`${actionName}执行失败：${error.message || String(error)}`, true);
  } finally {
    setActionsDisabled(false);
  }
}

function setActionsDisabled(disabled) {
  runOrderBtn.disabled = disabled;
  runOrderDetailsBtn.disabled = disabled;
  runRefundDetailsBtn.disabled = disabled;
  runJzgBtn.disabled = disabled;
}

function getActionName(exportType) {
  switch (exportType) {
    case 'order_export':
      return '订单导出';
    case 'order_details':
      return '订单明细导出';
    case 'refund_details':
      return '放退款明细导出';
    case 'jzg_bill':
      return '金掌柜账单导出';
    default:
      return '导出';
  }
}

function renderSessionOptions(list, selectedValue) {
  const sessions = normalizeSessions(list);
  sessionSelect.innerHTML = '';

  const emptyOption = document.createElement('option');
  emptyOption.value = '';
  emptyOption.textContent = '不指定';
  sessionSelect.appendChild(emptyOption);

  sessions.forEach((session) => {
    const option = document.createElement('option');
    option.value = session;
    option.textContent = session;
    sessionSelect.appendChild(option);
  });

  sessionSelect.value = sessions.includes(selectedValue) ? selectedValue : '';
}

function getSessionOptions() {
  return Array.from(sessionSelect.options)
    .map((option) => option.value.trim())
    .filter((value) => value);
}

function normalizeSessions(input) {
  if (!Array.isArray(input)) {
    return [];
  }

  const unique = [];
  input.forEach((item) => {
    const text = String(item || '').trim();
    if (!text || unique.includes(text)) {
      return;
    }
    unique.push(text);
  });
  return unique;
}

function runtimeSendMessage(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}

function setStatus(text, isError = false, isOk = false) {
  statusEl.textContent = text;
  statusEl.classList.remove('error', 'ok');
  if (isError) statusEl.classList.add('error');
  if (isOk) statusEl.classList.add('ok');
}

function storageGet(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get([key], (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(result[key]);
    });
  });
}

function storageSet(key, value) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ [key]: value }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
